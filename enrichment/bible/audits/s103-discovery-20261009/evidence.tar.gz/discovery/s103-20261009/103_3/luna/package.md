# S103: ayah 103:3 with its frozen r13 commentary

## Ayat (Arabic)

103:3	إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّٰلِحَٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ

## Words, roots and branches named by the frozen surah commentary

These are source labels, not dictionary definitions or verified cross-language cognates.

ayah	word	root	branch	image
103:3	ءَامَنُوا۟	ء م ن	B001	Sermaye, alışveriş ve günün ücreti
103:3	وَعَمِلُوا۟	ع م ل	B001	Sermaye, alışveriş ve günün ücreti
103:3	وَعَمِلُوا۟	ع م ل	B004	Sermaye, alışveriş ve günün ücreti
103:3	وَعَمِلُوا۟	ع م ل	B005	Sermaye, alışveriş ve günün ücreti
103:3	وَعَمِلُوا۟	ع م ل	B006	Sermaye, alışveriş ve günün ücreti
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B001	Sermaye, alışveriş ve günün ücreti
103:3	بِٱلْحَقِّ	ح ق ق	B002	Sermaye, alışveriş ve günün ücreti
103:3	بِٱلْحَقِّ	ح ق ق	B003	Sermaye, alışveriş ve günün ücreti
103:3	بِٱلصَّبْرِ	ص ب ر	B003	Sermaye, alışveriş ve günün ücreti
103:3	بِٱلصَّبْرِ	ص ب ر	B011	Sermaye, alışveriş ve günün ücreti
103:3	وَتَوَاصَوْا۟	و ص ي	B001	Gecenin gündüze eklenmesi
103:3	بِٱلْحَقِّ	ح ق ق	B008	Gecenin gündüze eklenmesi
103:3	بِٱلْحَقِّ	ح ق ق	B011	Gecenin gündüze eklenmesi
103:3	بِٱلْحَقِّ	ح ق ق	B013	Gecenin gündüze eklenmesi
103:3	بِٱلصَّبْرِ	ص ب ر	B007	Gecenin gündüze eklenmesi
103:3	بِٱلصَّبْرِ	ص ب ر	B014	Gecenin gündüze eklenmesi
103:3	بِٱلصَّبْرِ	ص ب ر	B004	Sıkma, öz ve ağzı kapalı şişe
103:3	بِٱلصَّبْرِ	ص ب ر	B008	Sıkma, öz ve ağzı kapalı şişe
103:3	بِٱلصَّبْرِ	ص ب ر	B018	Sıkma, öz ve ağzı kapalı şişe
103:3	بِٱلصَّبْرِ	ص ب ر	B001	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	بِٱلصَّبْرِ	ص ب ر	B002	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	بِٱلصَّبْرِ	ص ب ر	B012	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	بِٱلصَّبْرِ	ص ب ر	B013	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	بِٱلصَّبْرِ	ص ب ر	B014	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	بِٱلصَّبْرِ	ص ب ر	B015	Tutmak: kendini tutan, tutulan ve elini tutan
103:3	ءَامَنُوا۟	ء م ن	B001	Sığınak ve kurtuluş
103:3	بِٱلْحَقِّ	ح ق ق	B007	Sığınak ve kurtuluş
103:3	بِٱلصَّبْرِ	ص ب ر	B003	Sığınak ve kurtuluş
103:3	بِٱلصَّبْرِ	ص ب ر	B006	Sığınak ve kurtuluş
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B005	Sığınak ve kurtuluş
103:3	وَتَوَاصَوْا۟	و ص ي	B001	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	وَتَوَاصَوْا۟	و ص ي	B004	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	بِٱلْحَقِّ	ح ق ق	B013	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	بِٱلصَّبْرِ	ص ب ر	B005	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	بِٱلصَّبْرِ	ص ب ر	B010	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	بِٱلصَّبْرِ	ص ب ر	B011	Yağmur bulutu, birbirine eklenen bitki ve kasırga
103:3	ءَامَنُوا۟	ء م ن	B001	Yük hayvanı ve yol
103:3	وَعَمِلُوا۟	ع م ل	B008	Yük hayvanı ve yol
103:3	وَعَمِلُوا۟	ع م ل	B010	Yük hayvanı ve yol
103:3	وَعَمِلُوا۟	ع م ل	B011	Yük hayvanı ve yol
103:3	وَعَمِلُوا۟	ع م ل	B012	Yük hayvanı ve yol
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B001	Yük hayvanı ve yol
103:3	بِٱلْحَقِّ	ح ق ق	B008	Yük hayvanı ve yol
103:3	بِٱلْحَقِّ	ح ق ق	B012	Yük hayvanı ve yol
103:3	بِٱلْحَقِّ	ح ق ق	B014	Yük hayvanı ve yol
103:3	بِٱلصَّبْرِ	ص ب ر	B005	Yük hayvanı ve yol
103:3	بِٱلصَّبْرِ	ص ب ر	B017	Yük hayvanı ve yol
103:3	ءَامَنُوا۟	ء م ن	B002	Görmek, doğrulamak, emin olmak
103:3	وَعَمِلُوا۟	ع م ل	B002	Görmek, doğrulamak, emin olmak
103:3	وَعَمِلُوا۟	ع م ل	B010	Görmek, doğrulamak, emin olmak
103:3	بِٱلْحَقِّ	ح ق ق	B001	Görmek, doğrulamak, emin olmak
103:3	بِٱلْحَقِّ	ح ق ق	B005	Görmek, doğrulamak, emin olmak
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B002	Çekişmeden birlikteliğe
103:3	بِٱلْحَقِّ	ح ق ق	B004	Çekişmeden birlikteliğe
103:3	وَتَوَاصَوْا۟	و ص ي	B003	Çekişmeden birlikteliğe
103:3	بِٱلصَّبْرِ	ص ب ر	B003	Çekişmeden birlikteliğe
103:3	وَتَوَاصَوْا۟	و ص ي	B002	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	ءَامَنُوا۟	ء م ن	B001	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	بِٱلْحَقِّ	ح ق ق	B002	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	بِٱلْحَقِّ	ح ق ق	B003	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	بِٱلصَّبْرِ	ص ب ر	B002	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	بِٱلصَّبْرِ	ص ب ر	B003	Geride bırakılan emanet: vasiyet, tanık ve kefil
103:3	وَعَمِلُوا۟	ع م ل	B002	Sapmayan darbe
103:3	وَعَمِلُوا۟	ع م ل	B009	Sapmayan darbe
103:3	بِٱلْحَقِّ	ح ق ق	B009	Sapmayan darbe
103:3	بِٱلصَّبْرِ	ص ب ر	B002	Sapmayan darbe
103:3	وَعَمِلُوا۟	ع م ل	B002	Sıkı dokuma, yerine oturan kapı ve örümceğin evi
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B001	Sıkı dokuma, yerine oturan kapı ve örümceğin evi
103:3	وَتَوَاصَوْا۟	و ص ي	B001	Sıkı dokuma, yerine oturan kapı ve örümceğin evi
103:3	بِٱلْحَقِّ	ح ق ق	B010	Sıkı dokuma, yerine oturan kapı ve örümceğin evi
103:3	بِٱلْحَقِّ	ح ق ق	B011	Sıkı dokuma, yerine oturan kapı ve örümceğin evi
103:3	وَعَمِلُوا۟	ع م ل	B001	Herkesi işiyle vadesine getiren gün
103:3	ٱلصَّٰلِحَٰتِ	ص ل ح	B001	Herkesi işiyle vadesine getiren gün
103:3	بِٱلْحَقِّ	ح ق ق	B002	Herkesi işiyle vadesine getiren gün
103:3	بِٱلْحَقِّ	ح ق ق	B006	Herkesi işiyle vadesine getiren gün
103:3	بِٱلصَّبْرِ	ص ب ر	B013	Herkesi işiyle vadesine getiren gün

## Semitic root table (Hebrew and Biblical Aramaic correspondences of the Arabic roots above)

Generated by enrichment/bible/hebrew.py from the Open Scriptures lexicon and the WLC lemmas. A regular sound
correspondence is a candidate, not proof of cognacy; "BDB cites an Arabic cognate" is the lexicon's own note.

== Arabic root ء م ن: 2 Hebrew/Aramaic correspondences found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew אמנ (ء→א م→מ ن→נ): sound correspondence only (unverified); 343 WLC occurrences; `hebrew.py root אמנ` lists them
  - אָמוֹן (ʾāmôn) N 'artificer' [H527; Hebrew; 1 WLC occurrence] Strong: a throng of people
  - אָמוֹן (ʾāmôn) N 'artificer' [H525; Hebrew; 1 WLC occurrence] Strong: skilled, i.e. an architect
  - אֱמוּנָה (ʾĕmûnâ) N 'firmness' [H530; Hebrew; 49 WLC occurrences] Strong: literally firmness; figuratively security; morally fidelity
  - אֵמֻן (ʾēmun) N 'trusting' [H529; Hebrew; 5 WLC occurrences] Strong: established, i.e. (figuratively) trusty; also (abstractly) trustworthiness
  - אָמֵן (ʾāmēn) D 'verily' [H543; Hebrew; 30 WLC occurrences] Strong: sure; abstract, faithfulness; adverb, truly
  - אָמַן (ʾāman) V 'confirm' [H539; Hebrew; 108 WLC occurrences] Strong: properly, to build up or support; to foster as a parent or nurse; figuratively to render (or be) firm or faithful, to trust or believe, to be permanent or quiet; morally to be true or certain;
  - אָמָּן (ʾāmmān) N 'master-workman' [H542; Hebrew; 1 WLC occurrence] Strong: an expert
  - אֹ֫מֶן (ʾōmen) N 'faithfulness' [H544; Hebrew; 1 WLC occurrence] Strong: verity
  - אֲמָנָה (ʾămānâ) N 'faith' [H548; Hebrew; 2 WLC occurrences] Strong: something fixed, i.e. a covenant. an allowance
  - אֹמְנָה (ʾōmĕnâ) N 'confirm' [H547; Hebrew; 1 WLC occurrence] Strong: a column
  - אׇמְנָה (ʾomnâ) D 'verily' [H546; Hebrew; 2 WLC occurrences] Strong: adverb, surely
  - אׇמְנָה (ʾomnâ) N 'bringing up' [H545; Hebrew; 1 WLC occurrence] Strong: tutelage
  - אֻמְנָם (ʾumnām) D 'verily' [H552; Hebrew; 5 WLC occurrences]
  - אׇמְנָם (ʾomnām) D 'verily' [H551; Hebrew; 9 WLC occurrences] Strong: verily
  - אֱמֶת (ʾĕmet) N 'firmness' [H571; Hebrew; 127 WLC occurrences] Strong: stability; (figuratively) certainty, truth, trustworthiness
* Aramaic אמנ (ء→א م→מ ن→נ): sound correspondence only (unverified); 3 WLC occurrences; `hebrew.py root אמנ` lists them
  - אֲמַן (ʾăman) V 'trust' [H540; Aramaic; 3 WLC occurrences]

== Arabic root ح ق ق: 1 Hebrew/Aramaic correspondence found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew חקק (ح→ח ق→ק ق→ק): sound correspondence only (unverified); 254 WLC occurrences; `hebrew.py root חקק` lists them
  - חֹק (ḥōq) N 'something prescribed' [H2706; Hebrew; 127 WLC occurrences] Strong: an enactment; hence, an appointment (of time, space, quantity, labor or usage)
  - חֻקָּה (ḥuqqâ) N 'something prescribed' [H2708; Hebrew; 105 WLC occurrences]
  - חֵקֶק (ḥēqeq) N 'something prescribed' [H2711; Hebrew; 2 WLC occurrences] Strong: an enactment, a resolution
  - חָקַק (ḥāqaq) V 'cut in' [H2710; Hebrew; 19 WLC occurrences] Strong: properly, to hack, i.e. engrave (Judges 5:14, to be a scribe simply); by implication, to enact (laws being cut in stone or metal tablets in primitive times) or (gen.) prescribe
  - חֻקֹֿק (ḥuqōq) Np 'Hukkok' [H2712a; Hebrew; 1 WLC occurrence] Strong: Chukkok or Chukok, a place in Palestine

== Arabic root خ س ر: 3 Hebrew/Aramaic correspondences found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew חשר (خ→ח س→ש ر→ר): BDB cites an Arabic cognate; 2 WLC occurrences; `hebrew.py root חשר` lists them
  - חִשֻּׁר (ḥiššur) N 'nave' [H2840; Hebrew; 1 WLC occurrence] Strong: combined, i.e. the nave or hub of a wheel (as holding the spokes together)
  - חַשְׁרָה (ḥašrâ) N 'collection' [H2841; Hebrew; 1 WLC occurrence] Strong: properly, a combination or gathering, i.e. of watery clouds
* Hebrew חסר (خ→ח س→ס ر→ר): sound correspondence only (unverified); 59 WLC occurrences; `hebrew.py root חסר` lists them
  - חֶ֫סֶר (ḥeser) N 'want' [H2639; Hebrew; 2 WLC occurrences] Strong: lack; hence, destitution
  - חָסֵר (ḥāsēr) A 'needy' [H2638; Hebrew; 19 WLC occurrences] Strong: lacking; hence, without
  - חָסֵר (ḥāsēr) V 'lack' [H2637; Hebrew; 21 WLC occurrences] Strong: to lack; by implication, to fail, want, lessen
  - חֹ֫סֶר (ḥōser) N 'want' [H2640; Hebrew; 3 WLC occurrences] Strong: poverty
  - חֶסְרוֹן (ḥesrôn) N 'thing lacking' [H2642; Hebrew; 1 WLC occurrence] Strong: deficiency
  - מַחְסוֹר (maḥsôr) N 'need' [H4270; Hebrew; 13 WLC occurrences] Strong: deficiency; hence, impoverishment
* Aramaic חסר (خ→ח س→ס ر→ר): sound correspondence only (unverified); 1 WLC occurrences; `hebrew.py root חסר` lists them
  - חַסִּר (ḥassir) A 'lacking' [H2627; Aramaic; 1 WLC occurrence] Strong: deficient

== Arabic root ص ب ر: 1 Hebrew/Aramaic correspondence found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew צבר (ص→צ ب→ב ر→ר): sound correspondence only (unverified); 8 WLC occurrences; `hebrew.py root צבר` lists them
  - צִבּוּר (ṣibbûr) N 'heap' [H6652; Hebrew; 1 WLC occurrence] Strong: a pile
  - צָבַר (ṣābar) V 'heap up' [H6651; Hebrew; 7 WLC occurrences] Strong: to aggregate

== Arabic root ص ل ح: 2 Hebrew/Aramaic correspondences found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew צלח (ص→צ ل→ל ح→ח): sound correspondence only (unverified); 70 WLC occurrences; `hebrew.py root צלח` lists them
  - צָלֵחַ (ṣālēaḥ) V 'advance' [H6743b; Hebrew; 55 WLC occurrences] Strong: to push forward, in various senses (literal or figurative, transitive or intransitive)
  - צָלַח (ṣālaḥ) V 'rush' [H6743a; Hebrew; 10 WLC occurrences] Strong: to push forward, in various senses (literal or figurative, transitive or intransitive)
  - צֵלָחָה (ṣēlāḥâ) N 'pot' [H6745; Hebrew; 1 WLC occurrence] Strong: something protracted or flattened out, i.e. a platter
  - צְלֹחִית (ṣĕlōḥît) N 'jar' [H6746; Hebrew; 1 WLC occurrence] Strong: something prolonged or tall, i.e. a vial or salt-cellar
  - צַלַּ֫חַת (ṣallaḥat) N 'dish' [H6747; Hebrew; 3 WLC occurrences] Strong: something advanced or deep, i.e. a bowl; figuratively, the bosom
* Aramaic צלח (ص→צ ل→ל ح→ח): sound correspondence only (unverified); 4 WLC occurrences; `hebrew.py root צלח` lists them
  - צְלַח (ṣĕlaḥ) V 'prosper' [H6744; Aramaic; 4 WLC occurrences] Strong: to advance (transitive or intransitive)

== Arabic root ع ص ر: 1 Hebrew/Aramaic correspondence found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew עצר (ع→ע ص→צ ر→ר): sound correspondence only (unverified); 63 WLC occurrences; `hebrew.py root עצר` lists them
  - מַעְצוֹר (maʿṣôr) N 'restraint' [H4622; Hebrew; 1 WLC occurrence] Strong: objectively, a hindrance
  - מַעְצָר (maʿṣār) N 'restraint' [H4623; Hebrew; 1 WLC occurrence] Strong: subjectively, control
  - עֶ֫צֶר (ʿeṣer) N 'restraint' [H6114; Hebrew; 1 WLC occurrence] Strong: restraint
  - עָצַר (ʿāṣar) V 'restrain' [H6113; Hebrew; 46 WLC occurrences] Strong: to inclose; by analogy, to hold back; also to maintain, rule, assemble
  - עֹ֫צֶר (ʿōṣer) N 'restraint' [H6115; Hebrew; 3 WLC occurrences] Strong: closure; also constraint
  - עֲצָרָה (ʿăṣārâ) N 'assembly' [H6116; Hebrew; 11 WLC occurrences] Strong: an assembly, especially on a festival or holiday

== Arabic root ع م ل: 1 Hebrew/Aramaic correspondence found in the lexicon (regular sound correspondences; a candidate, not proof)
* Hebrew עמל (ع→ע م→מ ل→ל): sound correspondence only (unverified); 76 WLC occurrences; `hebrew.py root עמל` lists them
  - עָמֵל (ʿāmēl) A 'toiling' [H6001b; Hebrew; 5 WLC occurrences] Strong: toiling; concretely, a laborer; figuratively, sorrowful
  - עָמֵל (ʿāmēl) N 'laborer' [H6001a; Hebrew; 4 WLC occurrences] Strong: toiling; concretely, a laborer; figuratively, sorrowful
  - עָמַל (ʿāmal) V 'labour' [H5998; Hebrew; 11 WLC occurrences] Strong: to toil, i.e. work severely and with irksomeness
  - עָמָל (ʿāmāl) N 'trouble' [H5999; Hebrew; 55 WLC occurrences] Strong: toil, i.e. wearing effort; hence, worry, whether of body or mind
  - עָמָל (ʿāmāl) Np 'Amal' [H6000; Hebrew; 1 WLC occurrence] Strong: Amal, an Israelite

== Arabic root و ص ي: 0 Hebrew/Aramaic correspondences found in the lexicon (regular sound correspondences; a candidate, not proof)
  no Hebrew or Aramaic root with these corresponding consonants is in the lexicon


## Frozen commentary (Turkish)

## Bir istisna, dört fiil

İkinci ayet insanı tek bir hükümle kaybın içine yerleştirmişti: {ar:إِنَّ ٱلْإِنسَٰنَ لَفِى خُسْرٍ, tr:inne'l-insâne le-fî husr, gloss:insan gerçekten kayıp içindedir, source:103:2}. Üçüncü ayet o hükmün içinden bir topluluğu ayırarak açılır: {ar:إِلَّا ٱلَّذِينَ ءَامَنُوا۟, tr:illellezîne âmenû, gloss:ancak inananlar hariç, source:103:3}. İstisna dışarıdan yeni birilerini getirmez; herkesi içine alan cümleden birilerini çekip çıkarır. Bu yüzden kayıp, insanın kendi hâlinde kalınca içinde bulunduğu durum olarak kalır; kurtuluş ise o durumdan çıkılarak varılan yerdir. Surenin ölçüsü de aynı şeyi söyler: birinci ayet tek kelimedir, ikinci ayet dört, üçüncü ayet dokuz kelime. Kayıp kısa bir cümleyle söylenir; ondan çıkışın tarifi surenin en uzun ayetidir.

İkinci ayetin öznesi tekildir: "insan". İstisna ise çoğuldur: "o kimseler". Dört fiilden ikisi tek başına yapılabilir, ikisi yapılamaz. İnanmak ve iş yapmak her birinin kendi fiilidir; son iki fiil karşılıklıdır, birinin ötekine verdiği ve ötekinden aldığı bir şeydir. Fiil de tekrarlanır. Hakkı ve sabrı tek bir tavsiyede toplamak mümkünken ayet her birine kendi fiilini verir: {ar:وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ, tr:ve tevâsav bi'l-hakkı ve tevâsav bi's-sabr, gloss:birbirlerine hakkı tavsiye ettiler ve birbirlerine sabrı tavsiye ettiler, source:103:3}. Hak bir kez el değiştirir, sabır bir kez daha. Dört fiil de geçmiş zaman kalıbındadır; istisna edilenler yapacakları şeyle değil, yapmış oldukları ve artık onları tanımlayan şeyle anılır.

Aynı istisnanın ilk yarısı Kur'an'da iki yerde daha geçer ve orada bir ücretle kapanır. İncire ve zeytine, Sînîn dağına ve güvenli bir şehre yemin eden bir surede insanın en güzel biçimde yaratıldığı, sonra aşağıların aşağısına çevrildiği söylenir {source:95:5}, ardından istisna gelir: {ar:إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّٰلِحَٰتِ فَلَهُمْ أَجْرٌ غَيْرُ مَمْنُونٍۢ, tr:illellezîne âmenû ve amilu's-sâlihâti fe-lehum ecrun gayru memnûn, gloss:iman edip salih işler yapanlar hariç; onlara kesintisiz bir ücret vardır, source:95:6}. Göğün yarıldığı ve insanın Rabbine doğru zahmetle çabaladığı anlatılan bir başka surede de istisna aynı sözlerle ve aynı ücretle biter {source:84:25}. Bu ayet ise ilk yarıdan sonra ücretin adını anmaz; yerine iki karşılıklı fiil koyar. Kayıptan çıkış burada bir ödülle değil, insanların birbirine ne ilettiğiyle tarif edilir.

## Güvene girmek, güven vermek

Türkçede "iman" bir inancın, neye inanıldığının adı olarak yaşar. Arapça fiil önce bir hâli anlatır: korkunun bittiği hâli. {ar:الأمن ضد الخوف, tr:el-emnu ziddu'l-havf, gloss:emn korkunun zıddıdır, source:"ء م ن,B001"}; {ar:أصل الأمن طمأنينة النفس وزوال الخوف, tr:aslu'l-emni tuma'nînetu'n-nefsi ve zevâlu'l-havf, gloss:emnin aslı nefsin yatışması ve korkunun kalkmasıdır, source:"ء م ن,B001"}. Türkçe aynı kökü emin, emniyet ve emanet kelimelerinde hâlâ taşır; "iman" ise bu kardeşlerinden ayrılmış, yalnızca bir kanaatin adı olmuş gibidir. Ayetteki "âmenû" yine "inandılar" demektir; ama Arapça kulak bu inanmanın içinde, kişinin kendini bir güvenceye bırakmasını da duyar.

Araplar birinin korumasına giren kişi için {ar:استأمن إليه دخل في أمانه, tr:iste'mene ileyhi dehale fî emânih, gloss:onun güvencesine sığındı, onun emanına girdi, source:"ء م ن,B001"} derlerdi; insanın içinde güvende olduğu yere de {ar:مأمنه منزله الذي فيه أمنه, tr:me'manuhû menziluhu'llezî fîhi emnuh, gloss:me'meni, içinde güvende olduğu evidir, source:"ء م ن,B001"} denirdi. Kur'an bu kelimeyi bir sığınma sahnesinde kullanır. Allah Peygamber'e, müşriklerden biri ondan koruma isterse onu korumasına almasını, Allah'ın sözünü dinleyinceye kadar yanında tutmasını ve sonra şöyle yapmasını söyler: {ar:ثُمَّ أَبْلِغْهُ مَأْمَنَهُۥ, tr:summe eblighu me'menehû, gloss:sonra onu güvenli yerine ulaştır, source:9:6}. Güven burada varılacak bir yerdir. Birinci ayetin kelimesi de sığınak ve kurtuluş yeri diye anılır {source:"ع ص ر,B005"}; sığınağa koşan insanla oraya varan topluluğun sahnesi surenin bütününe aittir, bu ayetin payı ise oraya girenleri adlandıran ilk fiildir.

İman ile güvenin aynı cümlede durduğu bir tartışma vardır. İbrahim'in kavmi onunla Allah hakkında çekişir {source:6:80}; o ise onların ortak koştuklarından korkmadığını söyler ve sorar: {ar:فَأَىُّ ٱلْفَرِيقَيْنِ أَحَقُّ بِٱلْأَمْنِ, tr:fe-eyyu'l-ferîkayni ehakku bi'l-emn, gloss:iki topluluktan hangisi güvene daha layıktır, source:6:81}. Cevap hemen gelir: {ar:ٱلَّذِينَ ءَامَنُوا۟ وَلَمْ يَلْبِسُوٓا۟ إِيمَٰنَهُم بِظُلْمٍ أُو۟لَٰٓئِكَ لَهُمُ ٱلْأَمْنُ, tr:ellezîne âmenû ve lem yelbisû îmânehum bi-zulmin ulâike lehumu'l-emn, gloss:inanıp imanlarını bir haksızlıkla örtmeyenler; güven işte onlarındır, source:6:82}. İnananlar ile güven aynı kökten iki kelimedir ve soruyu taşıyan kelime de bu ayetin "hak" kelimesinin köküdür: güvene kimin hakkı vardır. Bu ayette de iman başta, hak sonradadır.

Kök yalnızca güvene girmeyi değil, güven vermeyi de anlatır: {ar:الأمانة ضد الخيانة ومعناها سكون القلب, tr:el-emânetu ziddu'l-hiyâneti ve ma'nâhâ sukûnu'l-kalb, gloss:emanet hıyanetin zıddıdır, anlamı kalbin yatışmasıdır, source:"ء م ن,B001"}. Aynı ailede insanların zararından korkmadığı güvenilir kişi de vardır {source:"ء م ن,B001"}. Buradan sonra okunacak imgeler, kelimelerin bu ayetteki anlamının yanında duyulur, onun yerine geçmez. Araplar uzun yola dayanan dişi deveye "emûn" derlerdi: {ar:الأمون الناقة الأمينة الوثيقة أو التي يؤمن فتورها وعثورها, tr:el-emûnu'n-nâkatu'l-emînetu'l-vesîka, gloss:emûn, gevşemesinden ve tökezlemesinden korkulmayan sağlam deve, source:"ء م ن,B001"}. Çölde binicinin hayatı bineğine bağlıdır: yolun ortasında gevşeyen ya da tökezleyen deve, sahibini susuz bir yerde bırakır. Emûn adı, böyle bir korkunun olmadığı hayvana verilir; güven onda bir duygu değil, yol boyunca sınanmış bir dayanıklılıktır. Bu imgenin yanında "inananlar" hem güvene girmiş olanlar hem de üzerine yük bırakılabilenlerdir.

Kur'an bu yükü açıkça anar. Allah emaneti göklere, yere ve dağlara sunduğunu, onların onu taşımaktan kaçınıp ondan korktuğunu, insanın ise yüklendiğini söyler: {ar:وَحَمَلَهَا ٱلْإِنسَٰنُ ۖ إِنَّهُۥ كَانَ ظَلُومًۭا جَهُولًۭا, tr:ve hamelehe'l-insânu innehû kâne zalûmen cehûlâ, gloss:insan onu yüklendi; o çok haksızlık eden, çok bilmeyendir, source:33:72}. Bu, ikinci ayetin insanıdır: yükü almış ama taşıyışı onu kayba götürebilecek olan. İstisna, aynı yükü sendelemeden taşıyanları ayırır.

Kökün ikinci yüzü doğrulamaktır: {ar:الإيمان التصديق, tr:el-îmânu't-tasdîk, gloss:iman doğru saymaktır, source:"ء م ن,B002"}. Birine "sana inanmıyorum" demek, ona güvenini vermemektir: {ar:وما أنت بمؤمن لنا أي مصدق لنا, tr:ve mâ ente bi-mu'minin lenâ ey musaddikın lenâ, gloss:sen bize inanmazsın, yani bizi doğru saymazsın, source:"ء م ن,B002"}. Bu söz Kur'an'da Yusuf'un kardeşlerinin ağzındadır. Yusuf'u kuyuya bıraktıktan sonra akşam vakti ağlayarak babalarına gelirler {source:12:16}, onu kurdun yediğini söylerler ve eklerler: {ar:وَمَآ أَنتَ بِمُؤْمِنٍۢ لَّنَا وَلَوْ كُنَّا صَٰدِقِينَ, tr:ve mâ ente bi-mu'minin lenâ ve lev kunnâ sâdikîn, gloss:doğru söylesek de sen bize inanmazsın, source:12:17}. Gömleğin üzerindeki sahte kanı gören Yakub güvenini bu söze vermez ve şunu seçer: {ar:بَلْ سَوَّلَتْ لَكُمْ أَنفُسُكُمْ أَمْرًۭا ۖ فَصَبْرٌۭ جَمِيلٌۭ, tr:bel sevvelet lekum enfusukum emrâ, fe-sabrun cemîl, gloss:hayır, nefsiniz size bir işi süsledi; artık güzel bir sabır, source:12:18}. İman her söze verilen bir güven değildir; tutmayan bir sözden esirgenir ve yerine sabır gelir. İmanın bir tanımı onu doğrudan hakka bağlar: {ar:إذعان النفس للحق على سبيل التصديق, tr:iz'ânu'n-nefsi li'l-hakkı alâ sebîli't-tasdîk, gloss:nefsin, doğru sayarak hakka boyun eğmesi, source:"ء م ن,B002"}. Ayetin ilk fiili, böylece, son fiillerin konusunu önceden gösterir. Türkçenin dua sonunda söylediği "âmin" de bu köktendir: {ar:آمين في الدعاء يمد ويقصر ومعناه كذلك فليكن, tr:âmîn fi'd-duâ, gloss:duada âmin; anlamı "öyle olsun"dur, source:"ء م ن,B003"}. İnanmak, bu kelimenin yanında, duyulan söze "öyle olsun" diyerek kendini ona bırakmaktır.

## Kasıtlı iş ve bozulmamış olan

Amel her olup biten değildir: {ar:كل فعل يكون من الحيوان بقصد, tr:kullu fi'lin yekûnu mine'l-hayevâni bi-kasd, gloss:canlıdan kasıtla çıkan her iş, source:"ع م ل,B001"}. Araplar elleriyle toprak işi yapan ekibe de bu kökten ad verirlerdi: {ar:العملة القوم يعملون بأيديهم ضروبا من العمل حفرا أو طيا أو نحوه, tr:el-amele, gloss:elleriyle kazmak, kuyu örmek gibi türlü işler yapan topluluk, source:"ع م ل,B006"}. Kuyu önce kazılır, sonra içi taşla örülür; örülmeyen kuyunun duvarı çöker ve su yeniden toprağın altında kalır. Amel, bu imgenin yanında, kazmakla bitmeyen, kazılanı ayakta tutan iştir. İşe yatkın deve de bu kökten adlanır: {ar:اليعملة الناقة النجيبة المطبوعة على العمل, tr:el-ya'mele, gloss:ya'mele, işe yaratılışından yatkın soylu deve, source:"ع م ل,B008"}; hayvanın bacakları onun "çalışanları"dır: {ar:عوامل الدابة قوائمه واحدها عاملة, tr:avâmilu'd-dâbbe, gloss:hayvanın işi gören bacakları, source:"ع م ل,B010"}. Yol için {ar:طريق معمل أي لحب مسلوك, tr:tarîkun mu'mel, gloss:çok yürünmüş, açılmış yol, source:"ع م ل,B011"} denir: yol yürünerek açılır, üzerinden geçilmeyen iz kaybolur. Yaya yolcuların adı da buradan gelir: {ar:المسافرون إذا مشوا على أرجلهم يسمون بني العمل, tr:benu'l-amel, gloss:yaya yürüyen yolculara "amel oğulları" denir, source:"ع م ل,B012"}. Kafa da işletilir: {ar:أعمل فلان ذهنه في كذا وكذا إذا دبره بفهمه, tr:a'mele zihnehû, gloss:zihnini çalıştırıp işi anlayışıyla tarttı, source:"ع م ل,B002"}. Bu kullanımların hepsinde amel bir iz bırakır: ayakta duran bir kuyu duvarı, açılmış bir yol, yorulmuş bacaklar.

İşin bir karşılığı vardır: {ar:العمالة أجر ما عمل, tr:el-umâletu ecru mâ amil, gloss:umâle, yapılan işin ücretidir, source:"ع م ل,B004"}; iki kişi arasındaki alışverişe de bu kökten muamele denir: {ar:عاملت الرجل أعامله معاملة في المبايعة وغيرها, tr:âmeltu'r-racule u'âmiluhû muâmeleten fi'l-mubâya'a, gloss:alışverişte ve başka işlerde adamla muamele ettim, source:"ع م ل,B005"}. Birinci ayetin kelimesi günün geç vaktini de adlandırdığı için, işin bitip ücretin vadesine geldiği bir akşamüstü sahnesi surenin bütününde kurulur {source:"ع ص ر,B001"}; bu ayetin o sahnedeki payı, çalışan ve ücret alan bu kelimedir. Kur'an ücreti, işi ve sabrı bir yerde art arda koyar. Her nefsin ölümü tadacağı ve Allah'a döndürüleceği söylendikten sonra {source:29:57} iman edip salih işler yapanlara cennetten köşkler vaat edilir ve ayet şöyle biter: {ar:نِعْمَ أَجْرُ ٱلْعَٰمِلِينَ, tr:ni'me ecru'l-âmilîn, gloss:çalışanların ücreti ne güzel, source:29:58}; çalışanların kim olduğu da hemen söylenir: {ar:ٱلَّذِينَ صَبَرُوا۟ وَعَلَىٰ رَبِّهِمْ يَتَوَكَّلُونَ, tr:ellezîne saberû ve alâ rabbihim yetevekkelûn, gloss:sabredenler ve Rablerine dayananlar, source:29:59}.

Ama iş tek başına kayıptan kurtarmaz. Peygamber'e insanlara şunu sorması emredilir: {ar:قُلْ هَلْ نُنَبِّئُكُم بِٱلْأَخْسَرِينَ أَعْمَٰلًا, tr:kul hel nunebbiukum bi'l-ahserîne a'mâlâ, gloss:de ki: işleri bakımından en çok kaybedenleri size haber verelim mi, source:18:103}. Bunlar dünya hayatında çabaları boşa giden ama iyi iş yaptıklarını sananlardır {source:18:104}; işleri boşa çıkar ve {ar:فَلَا نُقِيمُ لَهُمْ يَوْمَ ٱلْقِيَٰمَةِ وَزْنًۭا, tr:fe-lâ nukîmu lehum yevme'l-kıyâmeti veznâ, gloss:kıyamet günü onlar için bir tartı kurmayız, source:18:105}. İkinci ayetin kayıp kelimesi burada işin kendisine yapışır. Bu yüzden ayet "iş yaptılar" demez, işin niteliğini söyler.

O nitelik "es-sâlihât"tır. Kelime bir sıfattır; nitelediği şey adıyla anılmaz, yalnızca hâli söylenir: "sağlam olanlar, bozulmamış olanlar". Kökün aslı bozulmanın karşıtıdır: {ar:أصل واحد يدل على خلاف الفساد, tr:aslun vâhidun yedullu alâ hilâfi'l-fesâd, gloss:bozulmanın karşıtını gösteren tek bir kök, source:"ص ل ح,B001"}, ve bu karşıtlık en çok işler için kullanılır: {ar:الصلاح ضد الفساد مختصان في أكثر الاستعمال بالأفعال, tr:es-salâhu ziddu'l-fesâd, gloss:salâh bozukluğun zıddıdır; ikisi çoğunlukla işler için kullanılır, source:"ص ل ح,B001"}. Türkçede "salih" daha çok dindar bir kişinin sıfatıdır; Arapça kelime önce bir şeyin çürümemiş, yerinde ve işe yarar oluşunu anlatır. Araplar hayvanına iyi bakan için {ar:أصلحت إلى الدابة أحسنت إليها, tr:aslahtu ile'd-dâbbe, gloss:hayvana iyi davrandım, source:"ص ل ح,B001"} derlerdi; bir şey birine uygun düştüğünde de {ar:وهذا الشئ يصلح لك، أي هو من بابتك, tr:hâze'ş-şey'u yasluhu lek, gloss:bu sana uyar, senin türündendir, source:"ص ل ح,B003"} denirdi. Aynı kök insanlar arasındaki barışı da adlandırır: {ar:الصلح يختص بإزالة النفار بين الناس, tr:es-sulhu yahtassu bi-izâleti'n-nifâri beyne'n-nâs, gloss:sulh, insanlar arasındaki ürküp kaçışmayı gidermeye özgüdür, source:"ص ل ح,B002"}. Salih iş, bu kullanımların yanında, kendi içinde bozulmamış, yanındaki canlıya iyi gelen, yerine uyan ve insanları birbirinden ürkütmeyen iştir. Son yüzü, ayetin karşılıklı fiillerine kapı açar.

Kur'an aynı sıfatı zamanın aşındırmasına karşı kullanır. Peygamber'e dünya hayatının misalini vermesi söylenir: gökten inen suyla yerin bitkisi birbirine karışır, sonra rüzgârların savurduğu kuru çerçöpe döner {source:18:45}. Hemen ardından: {ar:ٱلْمَالُ وَٱلْبَنُونَ زِينَةُ ٱلْحَيَوٰةِ ٱلدُّنْيَا ۖ وَٱلْبَٰقِيَٰتُ ٱلصَّٰلِحَٰتُ خَيْرٌ عِندَ رَبِّكَ ثَوَابًۭا وَخَيْرٌ أَمَلًۭا, tr:el-mâlu ve'l-benûne zînetu'l-hayâti'd-dunyâ, ve'l-bâkıyâtu's-sâlihâtu hayrun inde rabbike sevâben ve hayrun emelâ, gloss:mal ve oğullar dünya hayatının süsüdür; kalıcı salih şeyler ise Rabbinin katında karşılıkça da umutça da daha hayırlıdır, source:18:46}. Burada "sâlihât" yine adı söylenmeden duran bir sıfattır ve yanına "kalıcı olanlar" eklenir. Zamanın erittiği sermayenin karşısında, bozulmadığı için kalan iş durur.

Bu ayetin tam aynası Kur'an'ın başka bir yerindedir. Kayıp kelimesiyle anılanlar şöyle tarif edilir: {ar:ٱلَّذِينَ يَنقُضُونَ عَهْدَ ٱللَّهِ مِنۢ بَعْدِ مِيثَٰقِهِۦ وَيَقْطَعُونَ مَآ أَمَرَ ٱللَّهُ بِهِۦٓ أَن يُوصَلَ وَيُفْسِدُونَ فِى ٱلْأَرْضِ ۚ أُو۟لَٰٓئِكَ هُمُ ٱلْخَٰسِرُونَ, tr:ellezîne yenkudûne ahdallâhi min ba'di mîsâkıhî ve yaktaûne mâ emerallâhu bihî en yûsale ve yufsidûne fi'l-ard, ulâike humu'l-hâsirûn, gloss:Allah'ın ahdini pekiştirildikten sonra bozan, Allah'ın bağlanmasını emrettiğini kesen ve yeryüzünde bozgunculuk yapanlar; kaybedenler işte onlardır, source:2:27}. Salih işin karşısında bozgunculuk, birbirine eklenmenin karşısında kesmek, istisnanın karşısında kayıp durur. "Bağlanmak" fiili bu ayette başka bir köktendir, tavsiye fiilinin kökü değildir; ama Araplar tavsiye kökünü de tam bu bağlama işiyle açıklarlardı.

## Birbirine eklenmek

Tavsiye kökünün aslı budur: {ar:أصل يدل على وصل شيء بشيء, tr:aslun yedullu alâ vasli şey'in bi-şey', gloss:bir şeyi bir şeye bağlamayı gösteren kök, source:"و ص ي,B001"}. Bir işi ara vermeden sürdüren için {ar:وصيت الليلة باليوم وصلتها, tr:vasaytu'l-leylete bi'l-yevm, gloss:geceyi gündüze ekledim, bağladım, source:"و ص ي,B001"} denirdi. Birinci ayetin kelimesi de gece ile gündüzü, sabah ile akşamüstünü ikili olarak adlandırır {source:"ع ص ر,B001"}; zamanın birbirine eklenen parçaları ile insanların birbirine eklenmesi surenin bütününde buluşan bir sahnedir, bu ayetin payı o eklemeyi yapan fiildir.

Kelimenin en canlı kullanımı bitkiyle ilgilidir. Çölde yağmurdan sonra ot önce öbek öbek çıkar; öbekler büyüyüp birbirine değdiğinde Araplar {ar:تواصى النبت إذا اتصل, tr:tevâsa'n-nebtu izâ'ttasal, gloss:bitki birbirine bitişince "tevâsâ" denir, source:"و ص ي,B001"} derlerdi. Bu ayetin fiili, aynı kalıpla, bitki için kullanılmış olur. Örtüsü kesintisiz yere {ar:أرض واصية متصلة النبات, tr:ardun vâsiye, gloss:bitkisi birbirine bağlı toprak, source:"و ص ي,B001"}, bir başka çöle uzanan çöle de {ar:فلاة واصية يتصل بفلاة أخرى, tr:felâtun vâsiye, gloss:başka bir çöle bitişen çöl, source:"و ص ي,B001"} denirdi. Bitişik otlağın işi şudur: sürü çıplak toprağı aşmadan bir öbekten ötekine geçer, yürüdükçe yer. Otlağın sürüye kendini bol bol vermesi de bu kökle söylenir: {ar:إذا أطاع المرعى للسائمة فأصابته رغدا قيل وصى لها المرتع يصي وصيا, tr:vasâ lehe'l-merta', gloss:otlak otlayan hayvana boyun eğip bolca yem verince "vasâ" denir, source:"و ص ي,B004"}. Bu imgenin yanında birbirine hakkı ve sabrı tavsiye edenler, tek tek öbeklerin birleşip kesintisiz bir yeşillik olmasına benzer: aralarında boşluk kalmaz ve her biri ötekinin beslendiği yer olur. Birinci ayetin kelimesinin yağmur yüklü bulutu da adlandırması {source:"ع ص ر,B003"}, yağmurdan yeşermeye uzanan bir sahneyi surenin bütününe bırakır.

Söz de bağlanır. Vasiyet, ardından gelene eklenen sözdür: {ar:الوصية من هذا القياس كأنه كلام يوصى أي يوصل, tr:el-vasiyyetu min hâze'l-kıyâs, keennehû kelâmun yûsâ ey yûsal, gloss:vasiyet bu köktendir; sanki bağlanan, eklenen bir sözdür, source:"و ص ي,B002"}. Bir tanımı onu doğrudan işe bağlar: {ar:التقدم إلى الغير بما يعمل به مقترنا بوعظ, tr:et-tekaddumu ile'l-gayri bimâ yu'melu bih, gloss:başkasına, öğütle birlikte, üzerinde çalışacağı bir şeyi önceden iletmek, source:"و ص ي,B002"}. Tavsiye edilen şey "üzerinde çalışılacak" şeydir; ayetin "amel"i ile "tevâsî"si bu tanımda aynı cümleye girer. Türkçede "tavsiye" hafif bir öneridir, uyulmasa da olur; "vasiyet" ise yalnızca ölüm döşeğinin sözüdür. Arapça kök ikisini birden ve daha fazlasını taşır: bağlayan, ardından geleni öncekine ekleyen, üzerinde iş yapılacak bir söz.

Ayetin kalıbı bu sözü karşılıklı kılar: {ar:تواصى القوم أي أوصى بعضهم بعضا, tr:tevâsa'l-kavmu ey evsâ ba'duhum ba'dâ, gloss:topluluk birbirine tavsiye etti, yani her biri ötekine tavsiye etti, source:"و ص ي,B003"}; aynı söz {ar:تواصى القوم إذا تواصلوا, tr:tevâsa'l-kavmu izâ tevâsalû, gloss:topluluk birbirine bağlandığında da "tevâsâ" denir, source:"و ص ي,B003"} anlamında da kullanılırdı. Kökün bir kelimesi bu karşılıklılığı tek başına taşır: {ar:الوصي الموصي والموصى إليه جميعا, tr:el-vasiyyu'l-mûsî ve'l-mûsâ ileyhi cemî'â, gloss:vasi, hem tavsiye eden hem kendisine tavsiye edilendir, source:"و ص ي,B002"}. Bu ayetteki topluluğun her üyesi, bu kelimenin iki anlamında birden vasidir: hem veren hem alan.

Kur'an bu bağlanan sözün kuşaktan kuşağa nasıl geçtiğini gösterir. İbrahim dini oğullarına tavsiye eder, Yakub da: {ar:وَوَصَّىٰ بِهَآ إِبْرَٰهِۦمُ بَنِيهِ وَيَعْقُوبُ, tr:ve vassâ bihâ İbrâhîmu benîhi ve Ya'kûb, gloss:İbrahim bunu oğullarına tavsiye etti, Yakub da, source:2:132}; Yakub ölüm döşeğinde oğullarına sorar: {ar:مَا تَعْبُدُونَ مِنۢ بَعْدِى, tr:mâ ta'budûne min ba'dî, gloss:benden sonra neye kulluk edeceksiniz, source:2:133}. Söz, ölen ile kalanı birbirine ekler. Peygamber'e insanları çağırıp Rablerinin onlara neyi yasakladığını okuması emredilen bir yerde, yasaklar ve buyruklar art arda sayılır ve her bölüm aynı sözle kapanır: {ar:ذَٰلِكُمْ وَصَّىٰكُم بِهِۦ لَعَلَّكُمْ تَعْقِلُونَ, tr:zâlikum vassâkum bihî leallekum ta'kılûn, gloss:size bunu tavsiye etti; belki aklınızı kullanırsınız, source:6:151}. Üçüncü bölümün konusu yolların dağılmasıdır: {ar:وَأَنَّ هَٰذَا صِرَٰطِى مُسْتَقِيمًۭا فَٱتَّبِعُوهُ ۖ وَلَا تَتَّبِعُوا۟ ٱلسُّبُلَ فَتَفَرَّقَ بِكُمْ عَن سَبِيلِهِۦ, tr:ve enne hâzâ sırâtî mustakîmen fettebi'ûh, ve lâ tettebi'u's-subule fe-teferraka bikum an sebîlih, gloss:bu benim dosdoğru yolumdur, ona uyun; başka yollara uymayın, sizi O'nun yolundan ayırıp dağıtır, source:6:153}. Tavsiyenin karşısındaki kelime dağılmaktır; bitişik otlağın karşısında parça parça çıplak toprak gibi.

Aynı karşılıklı fiil Kur'an'da bir kez daha iman edenler için gelir. Sarp bir yokuşa atılmayan insan anlatılır, yokuşun ne olduğu sorulur ve bir boynu çözmek, açlık gününde yakın bir yetimi ya da toprağa düşmüş bir yoksulu doyurmak diye açıklanır {source:90:13}; sonra: {ar:ثُمَّ كَانَ مِنَ ٱلَّذِينَ ءَامَنُوا۟ وَتَوَاصَوْا۟ بِٱلصَّبْرِ وَتَوَاصَوْا۟ بِٱلْمَرْحَمَةِ, tr:summe kâne mine'llezîne âmenû ve tevâsav bi's-sabri ve tevâsav bi'l-merhame, gloss:sonra iman edip birbirine sabrı ve merhameti tavsiye edenlerden oldu, source:90:17}. Orada fiil yine tekrarlanır ve sabır yine iki tavsiyeden biridir. Ama karşılıklı tavsiye kendiliğinden iyi değildir. Önceki nesillere hangi elçi geldiyse ona büyücü ya da deli dendiği anlatılır {source:51:52} ve sorulur: {ar:أَتَوَاصَوْا۟ بِهِۦ ۚ بَلْ هُمْ قَوْمٌۭ طَاغُونَ, tr:e-tevâsav bih, bel hum kavmun tâğûn, gloss:bunu birbirlerine mi tavsiye ettiler; hayır, onlar azgın bir topluluktur, source:51:53}. Söz kuşaktan kuşağa yanlışı da taşıyabilir. Bu yüzden ayet fiilin yanına nesnesini koyar: hakkı.

## Hak: yerine oturan, ödenmesi gereken

Hakkın aslı bir örtüşmedir: {ar:أصل الحق المطابقة والموافقة, tr:aslu'l-hakkı'l-mutâbakatu ve'l-muvâfaka, gloss:hakkın aslı örtüşme ve uygunluktur, source:"ح ق ق,B001"}, ve karşıtı boş olandır: {ar:الحق نقيض الباطل, tr:el-hakku nakîdu'l-bâtıl, gloss:hak batılın karşıtıdır, source:"ح ق ق,B001"}. Araplar bu örtüşmeyi bir kapıda görürlerdi. Eski kapılarda kanadın dikmesinin alt ucu eşikteki bir yuvaya oturur ve kapı o yuvada döner; uç yuvaya tam oturursa kapı sallanmadan açılır kapanır, oturmazsa kanat yalpalar. Bu yuvaya hak denirdi: {ar:مطابقة رجل الباب في حقه, tr:mutâbakatu ricli'l-bâbi fî hakkıh, gloss:kapı ayağının kendi yuvasına tam oturması, source:"ح ق ق,B011"}. İki kemiğin buluştuğu eklem de aynı adı alır: {ar:الحق ملتقى كل عظمين, tr:el-hakku multekâ kulli azmeyn, gloss:hak, iki kemiğin buluştuğu yerdir, source:"ح ق ق,B011"}. Sıkı dokunmuş kumaş ve sağlam kurulmuş söz de bu kökle anılır: {ar:ثوب محقق إذا كان محكم النسج, tr:sevbun muhakkak, gloss:sıkı ve düzgün dokunmuş kumaş, source:"ح ق ق,B010"}, {ar:كلام محقق أي رصين, tr:kelâmun muhakkak, gloss:sağlam, tutarlı söz, source:"ح ق ق,B010"}. At için bile söylenir: arka ayağını tam ön ayağının bastığı yere koyan ata {ar:الأحق الذي يضع رجله في موضع يده, tr:el-ehakk, gloss:arka ayağını ön ayağının izine koyan at, source:"ح ق ق,B014"} denirdi. Bütün bu kullanımlarda hak bir şeyin karşılığına tam oturmasıdır. Birbirine hakkı tavsiye etmek, bu imgenin yanında, bir kanaati değil, yerine oturan şeyi elden ele geçirmektir: sözün olana, işin söze, kişinin yüküne uyması.

Hakkın ikinci yüzü borçtur: {ar:حق الشيء وجب, tr:hakka'ş-şey'u vecebe, gloss:şey gerekli, ödenmesi zorunlu oldu, source:"ح ق ق,B002"}; kişiye düşen pay da haktır: {ar:هذه حقتي أي حقي, tr:hâzihî hıkkatî ey hakkî, gloss:bu benim payım, benim hakkımdır, source:"ح ق ق,B003"}. İkinci ayetin kayıp kelimesi tüccarın sermayesinden eksilmesini ve eksik tartmayı da adlandırır {source:"خ س ر,B002"}; pazar sahnesi surenin bütününe aittir, bu ayetin oradaki payı borcun ve payın adı olan hak kelimesidir. Kur'an bu kelimeyi borç ayetinde tam bu anlamda kullanır. Allah iman edenlere, belli bir süreye borçlandıklarında bunu yazmalarını söyler ve kimin yazdıracağını belirtir: {ar:وَلْيُمْلِلِ ٱلَّذِى عَلَيْهِ ٱلْحَقُّ, tr:velyumlili'llezî aleyhi'l-hakk, gloss:hak üzerinde olan, yani borçlu, yazdırsın, source:2:282}. Borçlu, hakkın kendi üzerinde olduğunu kendi ağzıyla söyleyen kişidir. Ertesi ayette yolculukta yazacak kimse bulunmazsa elde tutulan bir rehin istenir ve şöyle eklenir: {ar:فَإِنْ أَمِنَ بَعْضُكُم بَعْضًۭا فَلْيُؤَدِّ ٱلَّذِى ٱؤْتُمِنَ أَمَٰنَتَهُۥ, tr:fe-in emine ba'dukum ba'dan fel-yueddi'llezî'u'tumine emânetah, gloss:biriniz ötekine güvenirse, kendisine güvenilen emanetini ödesin, source:2:283}. İman kökü burada "birbiriniz" kalıbıyla karşılıklı işler, hak da üzerinde olanın teslim ettiği borçtur. Bu ayetin son iki fiili, aynı karşılıklılığı topluluğun bütün hayatına yayar: birbirine hakkı tavsiye etmek, herkesin ötekine neyi borçlu olduğunu birbirine hatırlatmasıdır.

Hak korunması gereken şeydir de. Araplar namusunu ve sancağını savunan kişiye {ar:حامي الحقيقة إذا حمى ما يحق عليه أن يحميه, tr:hâmi'l-hakîka, gloss:hakikatin koruyucusu, korumakla yükümlü olduğunu koruyan, source:"ح ق ق,B007"} derlerdi; aynı yerde hakikatin sancak anlamına geldiği de söylenirdi {source:"ح ق ق,B007"}. Türkçede "hakikat" soyut bir gerçeklik olarak kalmıştır; Arapça kelime bir de savaşta düşürülmemesi gereken sancağı, korunması üstüne borç olan şeyi anlatır. Hakkın bir yük olduğu da bir deve adında görünür: {ar:الحقة من أولاد الإبل ما استحق أن يحمل عليه, tr:el-hıkka, gloss:hıkka, üzerine yük vurulmayı hak edecek yaşa gelmiş genç devedir, source:"ح ق ق,B008"}. Ama aynı kök, deveyi gücünün üstünde sürmeyi de adlandırır: {ar:الحقحقة عند العرب أن يسار البعير ويحمل على ما يتعبه ولا يطيقه, tr:el-hakhaka, gloss:deveyi yoracak, kaldıramayacağı yük ve hızla sürmek, source:"ح ق ق,B012"}. Hak taşınacak yaşa gelmiş olana yüklenir; gücün üstündeki yük ise hakkın değil hırpalamanın adıdır. Kur'an'ın tavsiye listesinde bu ölçü açıkça yer alır: {ar:لَا نُكَلِّفُ نَفْسًا إِلَّا وُسْعَهَا, tr:lâ nukellifu nefsen illâ vus'ahâ, gloss:hiçbir nefse gücünün yettiğinden fazlasını yüklemeyiz, source:6:152}.

Hakkın bir de hareketi vardır. Mızrağın temrene yakın gövdesine, darbeyi taşıyan kısmına "âmil" denirdi: {ar:عامل الرمح ما يلي السنان وهو دون الثعلب, tr:âmilu'r-rumh, gloss:mızrağın âmili, temrenin hemen arkasındaki kısımdır, source:"ع م ل,B009"}; mızrağı işletmek de iş kökünün fiilidir: {ar:يستعمل غيره ويعمل رأيه أو كلامه أو رمحه, tr:yu'milu ra'yehû ev kelâmehû ev rumhah, gloss:görüşünü, sözünü ya da mızrağını işletir, source:"ع م ل,B002"}. Sapmadan hedefine giren darbe ise hak kökünden adlanır: {ar:طعنة محتقة أي لا زيغ فيها وقد نفذت, tr:ta'natun muhtakka, gloss:hiç sapmayan ve delip geçen darbe, source:"ح ق ق,B009"}. Mızrak kendi gövdesiyle itilir ve hak kökünün darbesi eğrilmeden içeri işler; bu ayetin iki kelimesi aynı silahın iki parçasında buluşur. Kur'an hakkı fırlatılan bir şey olarak anlatır. Göklerin ve yerin oyun için yaratılmadığı söylendikten sonra: {ar:بَلْ نَقْذِفُ بِٱلْحَقِّ عَلَى ٱلْبَٰطِلِ فَيَدْمَغُهُۥ فَإِذَا هُوَ زَاهِقٌۭ, tr:bel nakzifu bi'l-hakkı ale'l-bâtıli fe-yedmeğuhû fe-izâ huve zâhik, gloss:hayır, hakkı batılın üstüne fırlatırız, onun beynini parçalar ve o yok olup gider, source:21:18}. Haktan sapan için de yön kalmaz: {ar:فَمَاذَا بَعْدَ ٱلْحَقِّ إِلَّا ٱلضَّلَٰلُ ۖ فَأَنَّىٰ تُصْرَفُونَ, tr:fe-mâzâ ba'de'l-hakkı ille'd-dalâl, fe-ennâ tusrafûn, gloss:haktan sonra sapıklıktan başka ne var; nasıl da çevriliyorsunuz, source:10:32}.

Aynı hak bir kavganın da konusudur. Araplar iki tarafın her birinin hakkı kendinde görüp çekiştiği durum için {ar:تحاق القوم واحتقوا إذا تخاصموا, tr:tehâkka'l-kavmu vahtakkû, gloss:topluluk birbiriyle davalaştı, source:"ح ق ق,B004"} derlerdi; çekişip üstün gelen için de {ar:حاققته فحققته أي خاصمته في الحق فغلبته, tr:hâkaktuhû fe-hakaktuh, gloss:onunla hak üzerine çekiştim ve ona üstün geldim, source:"ح ق ق,B004"} denirdi. "Tehâkkû" ile "tevâsav" aynı karşılıklı kalıptadır. Birinde hak iki elin arasında çekiştirilir, ötekinde elden ele uzatılır. Ayet hakkı kavganın değil, tavsiyenin nesnesi yapar.

Hakkın son yüzü bir gündür: {ar:سميت حاقة لأنها تحق كل إنسان بعمله, tr:summiyet hâkkaten li-ennehâ tehukku kulle insânin bi-amelih, gloss:Hâkka diye adlandırıldı, çünkü her insanı işiyle yüzleştirip hakkını verir, source:"ح ق ق,B006"}. Bu tek ifadede surenin "insan"ı, bu ayetin "amel"i ve "hak"kı birlikte durur. Kur'an o günün adını bir surenin başına koyar ve sorar: {ar:ٱلْحَآقَّةُ, tr:el-hâkka, gloss:gerçekleşen gün, source:69:1}, {ar:وَمَآ أَدْرَىٰكَ مَا ٱلْحَآقَّةُ, tr:ve mâ edrâke me'l-hâkka, gloss:o gerçekleşen günün ne olduğunu sana ne bildirdi, source:69:3}. O gün hakkı birbirine iletmiş olanlar, kendilerine iletilen hakla karşılaşırlar.

## Sabır: kendini tutmak, birbirini tutmak

Türkçede sabır çoğu zaman edilgen bir bekleyiş, başa geleni sessizce çekmektir. Arapça kelimenin işi tutmaktır: {ar:الصبر حبس النفس عن الجزع, tr:es-sabru habsu'n-nefsi ani'l-ceza', gloss:sabır nefsi feryattan alıkoymaktır, source:"ص ب ر,B001"}; {ar:صبرت نفسي أي حبستها, tr:sabartu nefsî ey habestuhâ, gloss:nefsimi tuttum, alıkoydum, source:"ص ب ر,B001"}. Karşıtı da açıkça adlandırılır: {ar:الصبر نقيض الجزع, tr:es-sabru nakîdu'l-ceza', gloss:sabır feryadın karşıtıdır, source:"ص ب ر,B001"}. Kur'an insanın kendi hâlini tam bu karşıtla anlatır ve bu surenin kalıbıyla bir istisna kurar: {ar:إِنَّ ٱلْإِنسَٰنَ خُلِقَ هَلُوعًا, tr:inne'l-insâne hulika helû'â, gloss:insan pek tez canlı yaratıldı, source:70:19}, {ar:إِذَا مَسَّهُ ٱلشَّرُّ جَزُوعًۭا, tr:izâ messehu'ş-şerru cezû'â, gloss:kötülük dokununca feryat eder, source:70:20}, {ar:وَإِذَا مَسَّهُ ٱلْخَيْرُ مَنُوعًا, tr:ve izâ messehu'l-hayru menû'â, gloss:iyilik dokununca esirger, source:70:21}, {ar:إِلَّا ٱلْمُصَلِّينَ, tr:ille'l-musallîn, gloss:namaz kılanlar hariç, source:70:22}. Orada da "insan" tekil bir hükümle anılır, ardından bir topluluk ayrılır. Feryat eden insan, sabrın yokluğunda kalan insandır.

Tutmanın ters yüzü de aynı kelimededir: kendini tutmayan, tutulur. Araplar öldürülmek üzere bağlanıp alıkonmuş hayvana {ar:المصبورة المحبوسة على الموت, tr:el-masbûratu'l-mahbûsetu ale'l-mevt, gloss:ölüme alıkonmuş olan, source:"ص ب ر,B002"} derlerdi. Sabır ya kişinin kendine yaptığı bir tutmadır ya da başkasının ona yaptığı. Birinci ayetin kelimesi de alıkoymak diye açıklanır {source:"ع ص ر,B006"}; tutmanın bu iki yönünün buluştuğu sahne surenin bütününe aittir, bu ayetin payı kişinin kendi nefsini tutmasıdır. Oruç da bu tutmanın bir türü sayılırdı: {ar:سمي الصوم صبرا لكونه كالنوع له, tr:summiye's-savmu sabran, gloss:oruç, sabrın bir türü olduğu için sabır diye anıldı, source:"ص ب ر,B015"}. Beklemek de öyle: {ar:فاصبر لحكم ربك أي انتظر حكمه, tr:fasbir li-hukmi rabbik, ey intazır hukmeh, gloss:Rabbinin hükmüne sabret, yani hükmünü bekle, source:"ص ب ر,B014"}. Bekleyiş burada bir kendini tutma biçimidir; gevşeyip dağılmadan, zamanı gelene kadar yerinde durmak.

Bu tutmanın somut aletleri de kökte vardır. Şişenin ağzını kapatan tıpaya {ar:الصبار صمام القارورة, tr:es-sıbâru simâmu'l-kârûra, gloss:sıbâr, şişenin tıpasıdır, source:"ص ب ر,B018"} denirdi; kabın kenarlarına da {ar:أصبار الإناء نواحيه, tr:esbâru'l-inâ', gloss:kabın kenarları, source:"ص ب ر,B004"}. Tıpa içtekinin dökülmesini ve uçup gitmesini önler; kabın kenarı sıvıyı bir arada tutar. İkisi de içerideki şeyi korumak için sınır çizer. Sabır, bu imgenin yanında, insanın içindekini dökülmekten koruyan kenardır. Kur'an sabrı bir kaptan boşaltılan şey gibi anlatır. Firavun'un sihirbazları Musa'nın Rabbine inandıklarında Firavun onlara ellerini ve ayaklarını çaprazlama kestirip asacağını söyler {source:7:124}; onlar şöyle cevap verir: {ar:وَمَا تَنقِمُ مِنَّآ إِلَّآ أَنْ ءَامَنَّا بِـَٔايَٰتِ رَبِّنَا لَمَّا جَآءَتْنَا ۚ رَبَّنَآ أَفْرِغْ عَلَيْنَا صَبْرًۭا وَتَوَفَّنَا مُسْلِمِينَ, tr:ve mâ tenkımu minnâ illâ en âmennâ bi-âyâti rabbinâ lemmâ câetnâ, rabbenâ efrig aleynâ sabran ve teveffenâ muslimîn, gloss:bizden yalnızca Rabbimizin ayetleri bize gelince onlara inandığımız için öç alıyorsun; Rabbimiz, üzerimize sabır boşalt ve bizi Müslüman olarak öldür, source:7:126}. İman ile sabır burada da yan yanadır: iman edildiği için gelen tehdide, kaptan dökülür gibi gelen bir sabır istenir. Calût'un ordusunun karşısına çıkanlar da aynı duayı eder ve ayaklarının sağlam basmasını ister {source:2:250}.

Sabrın kendisi bir ilacın da adıdır: {ar:الصبر بكسر الباء عصارة شجرة, tr:es-sabir, gloss:sabir, bir ağaçtan sıkılan özdür, source:"ص ب ر,B008"}, {ar:الصبر هذا الدواء المر, tr:es-sabru hâze'd-devâu'l-murr, gloss:sabır, bu acı ilaç, source:"ص ب ر,B008"}. İlaç ağzı acıtır ama iyileştirir; işi hoşa gitmekle değil, bünyeyi düzeltmekle ölçülür. Birinci ayetin kelimesi sıkmayı da adlandırdığı için {source:"ع ص ر,B002"}, sıkılan ve sonunda bir öze dönüşen şeyin sahnesi surenin bütününde kurulur; bu ayetin payı o özün adı olan son kelimedir. Sabrın sertliği de taşta duyulur: {ar:الصبرة من الحجارة ما اشتد وغلظ, tr:es-subra mine'l-hicâra, gloss:taşlardan sert ve kalın olanı, source:"ص ب ر,B005"}; dağa da bu kökten ad verilir: {ar:الصبير الجبل, tr:es-sabîru'l-cebel, gloss:sabîr, dağdır, source:"ص ب ر,B017"}. Sabrın gerektiği yer de bir adla anılır: {ar:أم صبور أمر لا منفذ له عنه, tr:ummu sabûr, gloss:çıkış yolu olmayan iş, source:"ص ب ر,B006"}; kışın kemiğe işleyen soğuğu da öyle: {ar:صبارة الشتاء شدة برده, tr:sabâratu'ş-şitâ', gloss:kışın sert soğuğu, source:"ص ب ر,B007"}. Sabır, çıkışın olmadığı yerde ve soğuğun en sert anında kişinin yerinde durmasıdır.

Bu ayetin sabrı ise tek kişinin değil, birbirine iletilen bir sabırdır. Kök bunu da adlandırır: {ar:الصبير هو الكفيل, tr:es-sabîru huve'l-kefîl, gloss:sabîr kefildir, source:"ص ب ر,B003"}. Kefil, bir başkasının borcunun arkasında duran kişidir; borçlu ödeyemezse ödeme ona düşer. Araplar bir topluluğun kefiline şöyle derlerdi: {ar:صبير القوم الذي يصبر لهم ويكون معهم في أمورهم, tr:sabîru'l-kavmi'llezî yasbiru lehum ve yekûnu meahum fî umûrihim, gloss:topluluğun sabîri, onlar için katlanan ve işlerinde onlarla birlikte duran kişidir, source:"ص ب ر,B003"}. Birbirine sabrı tavsiye eden topluluk, bu imgenin yanında, birbirinin kefili olan bir topluluktur: biri gevşediğinde öteki onun yerine tutar. Bulutların bile birbirini taşıdığı söylenirdi: {ar:السحاب الأبيض الذي يصبر بعضه فوق بعض درجا, tr:es-sehâbu'l-ebyadu'llezî yasbiru ba'duhû fevka ba'd, gloss:basamak basamak birbirinin üstünde duran beyaz bulut, source:"ص ب ر,B010"}.

Kur'an sabrı bir topluluğun yanında durmak olarak da emreder. Allah Peygamber'e der ki: {ar:وَٱصْبِرْ نَفْسَكَ مَعَ ٱلَّذِينَ يَدْعُونَ رَبَّهُم بِٱلْغَدَوٰةِ وَٱلْعَشِىِّ يُرِيدُونَ وَجْهَهُۥ ۖ وَلَا تَعْدُ عَيْنَاكَ عَنْهُمْ تُرِيدُ زِينَةَ ٱلْحَيَوٰةِ ٱلدُّنْيَا, tr:vasbir nefseke ma'allezîne yed'ûne rabbehum bi'l-gadâti ve'l-aşiyyi yurîdûne vecheh, ve lâ ta'du aynâke anhum turîdu zînete'l-hayâti'd-dunyâ, gloss:sabah akşam Rablerine O'nun rızasını isteyerek dua edenlerle birlikte nefsini tut; dünya hayatının süsünü isteyerek gözlerin onlardan ayrılmasın, source:18:28}. Sabır burada bir yerde durmaktır, ama yalnız değil, bir topluluğun yanında. İman edenlere de karşılıklı bir sabır söylenir: {ar:يَٰٓأَيُّهَا ٱلَّذِينَ ءَامَنُوا۟ ٱصْبِرُوا۟ وَصَابِرُوا۟ وَرَابِطُوا۟, tr:yâ eyyuhe'llezîne âmenû'sbirû ve sâbirû ve râbitû, gloss:ey iman edenler, sabredin, sabırda birbirinizle yarışın ve bağlı durun, source:3:200}.

Sabrın bir de ters yüzü vardır ve o da tutmaktır, ama yanlış şeye: {ar:الصبر الجرأة ومنه فما أصبرهم على النار, tr:es-sabru'l-cur'a, gloss:sabır cüret anlamına da gelir; "ateşe ne kadar da dayanıklılar" sözü buradandır, source:"ص ب ر,B013"}. Kur'an bu sözü, Allah'ın indirdiği kitaptan bir kısmını gizleyip az bir bedele satanlar için söyler: {ar:أُو۟لَٰٓئِكَ ٱلَّذِينَ ٱشْتَرَوُا۟ ٱلضَّلَٰلَةَ بِٱلْهُدَىٰ وَٱلْعَذَابَ بِٱلْمَغْفِرَةِ ۚ فَمَآ أَصْبَرَهُمْ عَلَى ٱلنَّارِ, tr:ulâike'llezîne'şteravu'd-dalâlete bi'l-hudâ ve'l-azâbe bi'l-magfira, fe-mâ asbarahum ale'n-nâr, gloss:onlar hidayete karşılık sapıklığı, bağışlanmaya karşılık azabı satın alanlardır; ateşe ne kadar da dayanıklılar, source:2:175}. Kendini tutmak, yanlış bir alışverişe direnmeye de dönüşebilir. Ayetin sıralaması bu yüzden anlamlıdır: sabır, haktan sonra gelir ve onun ardından tavsiye edilir.

Sabrın karşılığı da kendi kelimesinin bir kullanımında duyulur. Araplar tartmadan, ölçmeden yığın hâlinde alınan mal için {ar:اشتريت الشيء صبرة أي بلا وزن ولا كيل, tr:iştereytu'ş-şey'e subraten, gloss:malı yığın hâlinde, tartmadan ve ölçmeden aldım, source:"ص ب ر,B011"} derlerdi. Kur'an'da Peygamber'e, iman eden kullara Rablerinden sakınmalarını, Allah'ın yerinin geniş olduğunu söylemesi emredilir ve söz şöyle biter: {ar:إِنَّمَا يُوَفَّى ٱلصَّٰبِرُونَ أَجْرَهُم بِغَيْرِ حِسَابٍۢ, tr:innemâ yuveffe's-sâbirûne ecrahum bi-gayri hisâb, gloss:sabredenlere ücretleri ancak hesapsız olarak tam ödenir, source:39:10}. Kelimenin bir kullanımı tartısız alınan yığını, ayet tartısız ödenen ücreti anlatır.

## Hakka dayanan sabır

Hak ile sabır Kur'an'da birbirine dayanarak gelir. Peygamber'e iki ayrı yerde aynı cümle söylenir: {ar:فَٱصْبِرْ إِنَّ وَعْدَ ٱللَّهِ حَقٌّۭ, tr:fasbir inne va'dallâhi hakk, gloss:sabret; Allah'ın vaadi haktır, source:40:55}. İkincisi bir uyarıyla devam eder: {ar:فَٱصْبِرْ إِنَّ وَعْدَ ٱللَّهِ حَقٌّۭ ۖ وَلَا يَسْتَخِفَّنَّكَ ٱلَّذِينَ لَا يُوقِنُونَ, tr:fasbir inne va'dallâhi hakkun ve lâ yestehıffenneke'llezîne lâ yûkınûn, gloss:sabret, Allah'ın vaadi haktır; kesin bilgiye ermemiş olanlar seni hafifliğe sürüklemesin, source:30:60}. Sabrın dayanağı hakkın kendisidir: vaat yerine oturacağı için beklemek anlamlıdır. Hakkı olmayan sabır cürete, sabrı olmayan hak ise hafifliğe döner; kesin bilgiye ermemişlerin sürüklediği şey de budur. Bu ayet ikisini ayrı ayrı tavsiye eder ama aynı sırayla: önce yerine oturan şey, sonra onu tutmanın gücü.

Bir babanın oğluna öğüdü bu sırayı bir hayat içinde gösterir. Lokman oğluna öğüt verirken önce ona Allah'a ortak koşmamasını söyler {source:31:13}; sözün arasına Allah'ın kendi sözü girer: {ar:وَوَصَّيْنَا ٱلْإِنسَٰنَ بِوَٰلِدَيْهِ, tr:ve vassayne'l-insâne bi-vâlideyh, gloss:insana anne babasını tavsiye ettik, source:31:14}. Tavsiye fiili ve ikinci ayetin "insan"ı aynı cümlededir. Lokman öğüdünü şöyle bitirir: {ar:يَٰبُنَىَّ أَقِمِ ٱلصَّلَوٰةَ وَأْمُرْ بِٱلْمَعْرُوفِ وَٱنْهَ عَنِ ٱلْمُنكَرِ وَٱصْبِرْ عَلَىٰ مَآ أَصَابَكَ ۖ إِنَّ ذَٰلِكَ مِنْ عَزْمِ ٱلْأُمُورِ, tr:yâ buneyye ekımi's-salâte ve'mur bi'l-ma'rûfi venhe ani'l-munkeri vasbir alâ mâ esâbek, inne zâlike min azmi'l-umûr, gloss:yavrum, namazı dosdoğru kıl, iyiliği emret, kötülükten alıkoy ve başına gelene sabret; bunlar kararlılık gerektiren işlerdendir, source:31:17}. Doğruyu söyleyen kişinin başına bir şey gelir; öğüt bunu bilir ve sabrı söylenen doğrunun hemen ardına koyar. Bu ayetteki sıra da aynıdır: hakkı birbirine ileten topluluk, o hakkın bedelini taşımak için birbirine sabrı da iletir.

Bu sabrın en ileri işi, kopmuş olanı birbirine eklemektir. Allah iyilik ile kötülüğün bir olmadığını söyler ve kötülüğü en güzel olanla savmayı emreder: {ar:فَإِذَا ٱلَّذِى بَيْنَكَ وَبَيْنَهُۥ عَدَٰوَةٌۭ كَأَنَّهُۥ وَلِىٌّ حَمِيمٌۭ, tr:fe-izellezî beyneke ve beynehû adâvetun keennehû veliyyun hamîm, gloss:bir de bakarsın, seninle arasında düşmanlık olan kişi sanki candan bir dost olmuştur, source:41:34}; ardından bu işin kime nasip olduğu söylenir: {ar:وَمَا يُلَقَّىٰهَآ إِلَّا ٱلَّذِينَ صَبَرُوا۟, tr:ve mâ yulakkâhâ illellezîne saberû, gloss:buna ancak sabredenler kavuşturulur, source:41:35}. Bu da bir istisnadır ve yine sabredenleri ayırır. Aralarında düşmanlık olan iki kişinin dost olması, birbirinden ayrı düşmüş iki öbeğin birleşip tek bir yeşillik olmasına benzer; o birleşmeyi taşıyan güç de nefsi feryattan alıkoyan, birbirinin kefili olan sabırdır.

## Whole surah (Arabic)

103:1	وَٱلْعَصْرِ
103:2	إِنَّ ٱلْإِنسَٰنَ لَفِى خُسْرٍ
103:3	إِلَّا ٱلَّذِينَ ءَامَنُوا۟ وَعَمِلُوا۟ ٱلصَّٰلِحَٰتِ وَتَوَاصَوْا۟ بِٱلْحَقِّ وَتَوَاصَوْا۟ بِٱلصَّبْرِ
