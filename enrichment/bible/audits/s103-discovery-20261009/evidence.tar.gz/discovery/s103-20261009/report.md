# S103 Bible discovery: s103-20261009

| Target | Reader | Attempt | Status | Initial | Proposals | New | Repeats | Final |
|---|---|---|---|---:|---:|---:|---:|---:|
| 103:1 | luna | s103-20261009 | ok | 67 | 53 | 53 | 0 | 120 |
| 103:1 | sol | s103-20261009 | ok | 132 | 61 | 61 | 0 | 193 |
| 103:2 | luna | s103-20261009 | ok | 63 | 47 | 47 | 0 | 110 |
| 103:2 | sol | s103-20261009 | ok | 96 | 73 | 73 | 0 | 169 |
| 103:3 | luna | s103-20261009 | ok | 138 | 37 | 37 | 0 | 175 |
| 103:3 | sol | s103-20261009 | ok | 185 | 138 | 138 | 0 | 323 |
| sec1 | luna | s103-20261009 | ok | 91 | 27 | 27 | 0 | 118 |
| sec1 | sol | s103-20261009 | ok | 172 | 66 | 66 | 0 | 238 |
| sec2 | luna | s103-20261009 | ok | 82 | 39 | 39 | 0 | 121 |
| sec2 | sol | s103-20261009 | ok | 130 | 60 | 60 | 0 | 190 |
| sec3 | luna | s103-20261009 | ok | 60 | 42 | 42 | 0 | 102 |
| sec3 | sol | s103-20261009 | ok | 72 | 36 | 36 | 0 | 108 |
| sec4 | luna | s103-20261009 | ok | 56 | 19 | 19 | 0 | 75 |
| sec4 | sol | s103-20261009 | ok | 125 | 80 | 80 | 0 | 205 |
| sec5 | luna | s103-20261009 | accepted | 77 | 49 | 49 | 0 | 126 |
| sec5 | sol | s103-20261009 | ok | 145 | 93 | 93 | 0 | 238 |
| sec6 | luna | s103-20261009 | ok | 47 | 36 | 36 | 0 | 83 |
| sec6 | sol | s103-20261009 | ok | 134 | 57 | 57 | 0 | 191 |
| sec7 | luna | s103-20261009 | ok | 108 | 40 | 40 | 0 | 148 |
| sec7 | sol | s103-20261009 | ok | 149 | 54 | 54 | 0 | 203 |
| sec8 | luna | s103-20261009 | ok | 88 | 59 | 59 | 0 | 147 |
| sec8 | sol | s103-20261009 | ok | 140 | 61 | 61 | 0 | 201 |
| sec9 | luna | s103-20261009 | accepted | 92 | 51 | 51 | 0 | 143 |
| sec9 | sol | s103-20261009 | ok | 146 | 62 | 62 | 0 | 208 |
| sec10 | luna | s103-20261009 | ok | 53 | 42 | 42 | 0 | 95 |
| sec10 | sol | s103-20261009 | ok | 115 | 54 | 54 | 0 | 169 |
| sec11 | luna | s103-20261009 | ok | 48 | 34 | 34 | 0 | 82 |
| sec11 | sol | s103-20261009 | ok | 73 | 56 | 56 | 0 | 129 |
| sec12 | luna | s103-20261009 | ok | 43 | 25 | 25 | 0 | 68 |
| sec12 | sol | s103-20261009 | ok | 95 | 44 | 44 | 0 | 139 |
| sec13 | luna | s103-20261009 | ok | 57 | 47 | 47 | 0 | 104 |
| sec13 | sol | s103-20261009 | ok | 108 | 40 | 40 | 0 | 148 |
| sec14 | luna | s103-20261009 | ok | 53 | 38 | 38 | 0 | 91 |
| sec14 | sol | s103-20261009 | ok | 72 | 48 | 48 | 0 | 120 |
| sec15 | luna | s103-20261009 | ok | 92 | 39 | 39 | 0 | 131 |
| sec15 | sol | s103-20261009 | ok | 104 | 100 | 100 | 0 | 204 |

## 103:1 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_1/luna/list.tsv",
    "rows": 120,
    "unique_references": 118,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 50,
      "medium": 62,
      "weak": 8
    },
    "findings": [
      {
        "line": 24,
        "ref": "Babylonian Talmud, Ta'anit 23a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Gregory of Tours, Glory of the Martyrs 1.95",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "Genesis Rabbah 89:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 33,
        "ref": "Mishnah Berakhot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "Babylonian Talmud, Berakhot 26b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "Tertullian, On Prayer 25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "WLC:Jonah.4.6",
        "raw_ref": "WLC:Jon.4.6",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 57,
        "ref": "WLC:Lev.23.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Lev.23.36",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Judg.13.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Judg.13.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:2Kgs.4.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:2Kgs.4.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Num.17.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Num.17.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Job.12.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 93,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 93,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 97,
        "ref": "Didache 8:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "Wisdom of Solomon 3:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_1/luna/followup.tsv",
    "rows": 53,
    "unique_references": 52,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 23,
      "medium": 29,
      "weak": 1
    },
    "findings": [
      {
        "line": 18,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 26,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "Didache 8:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "Wisdom of Solomon 3:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "first_turn_repair": {
    "policy": "bible-first-turn-repair-v1",
    "approval": "Accepted by the Claude Code Bible orchestrator (fork of the 2026-10-09 enrichment session) under the user's production go for S103; locator-only correction verified against the local WLC/SBLGNT/KJV text; no grade, kind, basis or explanation changed; listed for the user's review in the S103 Bible audit README.",
    "tool_audit_reviewed": true,
    "accepted_at": "2026-10-09T05:41:53.541692+00:00",
    "changes": [
      {
        "line": 64,
        "before": [
          "weak",
          "tevrat",
          "soydas",
          "WLC:Num.16.48",
          "Arabic ع ص ر / Hebrew עצר; table sound correspondence, unverified",
          "The commentary connects holding tightly with refuge and protection; Aaron stands between the dead and living while the plague is stopped with Hebrew עצר, a protective restraint that echoes that image."
        ],
        "after": [
          "weak",
          "tevrat",
          "soydas",
          "WLC:Num.17.13",
          "Arabic ع ص ر / Hebrew עצר; table sound correspondence, unverified",
          "The commentary connects holding tightly with refuge and protection; Aaron stands between the dead and living while the plague is stopped with Hebrew עצר, a protective restraint that echoes that image."
        ],
        "reason": "English verse numbering: KJV Numbers 16:48 (the plague restrained, Hebrew וַתֵּעָצַר) is WLC Numbers 17:13; checked in the local KJV and WLC"
      }
    ],
    "model_calls": 0,
    "artifacts": {
      "turn1.original.tsv": "bfbbee686f168bc29843f2df263009aca45d15598a8aa2e432f582291610ed38",
      "turn1.validation.failed.json": "8fe6a6a69d55eabfbd93613ef7a46788f3b32f2a093ab90deb8aaa4009fdaf6a",
      "turn1.tool_calls.json": "e536fcfeec72e4c78d582b32a2e62dbe6b970a411548dafb79aa38efddb860e0",
      "turn1.repair.proposed.json": "082bbec655bcdc014a430c31a22fd096b38aee62b76122bb104df1860c60ada6",
      "turn1.repair.proposed.tsv": "855033dde0354fd818d9b7251c8d71bfb93abae9fa8653945449c61a82cda5f5",
      "turn1.accepted.tsv": "855033dde0354fd818d9b7251c8d71bfb93abae9fa8653945449c61a82cda5f5"
    }
  },
  "usage_tokens": {
    "input_tokens": 782848,
    "cached_input_tokens": 651520,
    "cache_write_input_tokens": 0,
    "output_tokens": 93366,
    "reasoning_output_tokens": 80471,
    "total_tokens": 876214
  }
}
```

## 103:1 / sol / s103-20261009

```json
{
  "diagnostics": [
    {
      "call_id": "call_d427089ee612481bbf488e29d906695b",
      "message": "Script failed"
    },
    {
      "call_id": "call_d427089ee612481bbf488e29d906695b",
      "message": "Script error:"
    },
    {
      "call_id": "call_d427089ee612481bbf488e29d906695b",
      "message": "SyntaxError: Unexpected string"
    }
  ],
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_1/sol/list.tsv",
    "rows": 193,
    "unique_references": 193,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 114,
      "medium": 77,
      "weak": 2
    },
    "findings": [
      {
        "line": 10,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Job.12.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Joel.1.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Lev.23.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:Isa.66.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:Isa.66.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 40,
        "ref": "SBLGNT:Jas.4.13",
        "raw_ref": "SBLGNT:James.4.13",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 41,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 46,
        "ref": "Berakhot 26b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 75,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 75,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 76,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 76,
        "ref": "WLC:Job.27.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 111,
        "ref": "WLC:Gen.16.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 111,
        "ref": "WLC:Gen.16.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 112,
        "ref": "WLC:1Sam.21.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 112,
        "ref": "WLC:1Sam.21.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 113,
        "ref": "WLC:2Chr.7.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 113,
        "ref": "WLC:2Chr.7.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 114,
        "ref": "WLC:Joel.2.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 125,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 126,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 127,
        "ref": "Mishnah Avot 3:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 128,
        "ref": "Genesis Rabbah 89:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 129,
        "ref": "Gregory of Tours, Glory of the Martyrs 94",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 130,
        "ref": "Protevangelium of James 8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 153,
        "ref": "1 Maccabees 2:31",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 154,
        "ref": "1 Maccabees 2:38",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 155,
        "ref": "Sirach 4:31",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 156,
        "ref": "Tobit 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 157,
        "ref": "Didache 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 158,
        "ref": "Didache 1:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 166,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 187,
        "ref": "Tobit 4:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 188,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 189,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 190,
        "ref": "Mishnah Avot 5:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_1/sol/followup.tsv",
    "rows": 61,
    "unique_references": 61,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 49,
      "medium": 12
    },
    "findings": [
      {
        "line": 21,
        "ref": "1 Maccabees 2:31",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 22,
        "ref": "1 Maccabees 2:38",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "Sirach 4:31",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 24,
        "ref": "Tobit 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Didache 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 26,
        "ref": "Didache 1:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 55,
        "ref": "Tobit 4:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 56,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 58,
        "ref": "Mishnah Avot 5:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 562348,
    "cached_input_tokens": 496896,
    "cache_write_input_tokens": 0,
    "output_tokens": 28462,
    "reasoning_output_tokens": 14064,
    "total_tokens": 590810
  }
}
```

## 103:2 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_2/luna/list.tsv",
    "rows": 110,
    "unique_references": 106,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 85,
      "medium": 24,
      "weak": 1
    },
    "findings": [
      {
        "line": 3,
        "ref": "Gospel of Thomas 63",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 6,
        "ref": "SBLGNT:Jas.4.13",
        "raw_ref": "SBLGNT:James.4.13",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 7,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 12,
        "ref": "Sirach 11:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 13,
        "ref": "Wisdom of Solomon 5:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 15,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 16,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 17,
        "ref": "Shabbat 153a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 48,
        "ref": "WLC:Job.7.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Job.7.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 52,
        "ref": "WLC:Eccl.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 52,
        "ref": "WLC:Eccl.4.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "מְחַסֵּר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Eccl.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "עָמָל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֻקָּיו",
        "kind": "wording_review",
        "variant_matches": [
          {
            "after_word": 7,
            "reading": {
              "type": "x-qere",
              "text": "חֻקָּ֥יו",
              "words": [
                {
                  "lemma": "2706",
                  "morph": "HNcmpc/Sp3ms",
                  "id": "18Vg9",
                  "text": "חֻקָּ֥יו"
                }
              ]
            }
          }
        ],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Jer.17.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Jer.17.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אָנֻשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Deut.8.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Job.12.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Job.12.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "עָצַר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "SBLGNT:Jas.1.24",
        "raw_ref": "SBLGNT:James.1.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.90.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עָמָל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 94,
        "ref": "SBLGNT:Jas.5.2",
        "raw_ref": "SBLGNT:James.5.2",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 95,
        "ref": "SBLGNT:Jas.5.3",
        "raw_ref": "SBLGNT:James.5.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 98,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 101,
        "ref": "Didache 1.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 103,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 104,
        "ref": "Mishnah Avot 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 105,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 106,
        "ref": "Kiddushin 40b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 107,
        "ref": "Rosh Hashanah 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 108,
        "ref": "WLC:Ps.23.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "לֹא אֶחְסָר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [
          "WLC:Ps.23.1"
        ],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 109,
        "ref": "WLC:Isa.51.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 109,
        "ref": "WLC:Isa.51.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Jer.15.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Jer.15.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Jer.15.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אָנֻשָׁה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_2/luna/followup.tsv",
    "rows": 47,
    "unique_references": 46,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 38,
      "medium": 9
    },
    "findings": [
      {
        "line": 2,
        "ref": "WLC:Ps.90.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 2,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עָמָל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 2,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "SBLGNT:Jas.5.2",
        "raw_ref": "SBLGNT:James.5.2",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 32,
        "ref": "SBLGNT:Jas.5.3",
        "raw_ref": "SBLGNT:James.5.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 35,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 38,
        "ref": "Didache 1.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "Mishnah Avot 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 43,
        "ref": "Kiddushin 40b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 44,
        "ref": "Rosh Hashanah 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Ps.23.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "לֹא אֶחְסָר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [
          "WLC:Ps.23.1"
        ],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Isa.51.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Isa.51.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Jer.15.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Jer.15.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Jer.15.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אָנֻשָׁה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 691630,
    "cached_input_tokens": 541696,
    "cache_write_input_tokens": 0,
    "output_tokens": 71580,
    "reasoning_output_tokens": 59565,
    "total_tokens": 763210
  }
}
```

## 103:2 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_2/sol/list.tsv",
    "rows": 169,
    "unique_references": 167,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 110,
      "medium": 55,
      "weak": 4
    },
    "findings": [
      {
        "line": 6,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 6,
        "ref": "WLC:Eccl.2.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Eccl.1.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Eccl.1.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֶסְרוֹן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Prov.28.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "Mishnah Avot 3:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 51,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 52,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 74,
        "ref": "WLC:Jer.17.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 74,
        "ref": "WLC:Jer.17.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 80,
        "ref": "Mishnah Avot 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 81,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 84,
        "ref": "WLC:Ps.106.30",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 84,
        "ref": "WLC:Ps.106.30",
        "field": "note",
        "language": "Hebrew",
        "wording": "עָצַר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "WLC:Job.27.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 87,
        "ref": "Mishnah Avot 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 88,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 95,
        "ref": "WLC:2Sam.22.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "חשר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 96,
        "ref": "Ta'anit 23a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 106,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 106,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מַחְסוֹר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 127,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 132,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 143,
        "ref": "SBLGNT:Jas.1.23",
        "raw_ref": "SBLGNT:James.1.23",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 144,
        "ref": "SBLGNT:Jas.1.24",
        "raw_ref": "SBLGNT:James.1.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 145,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 146,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 151,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 153,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 153,
        "ref": "WLC:Job.4.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 157,
        "ref": "Mishnah Avot 3:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 158,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 159,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 162,
        "ref": "SBLGNT:Jas.1.25",
        "raw_ref": "SBLGNT:James.1.25",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 167,
        "ref": "Didache 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 168,
        "ref": "Gospel of Thomas 3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 169,
        "ref": "Epistle of Barnabas 18:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_2/sol/followup.tsv",
    "rows": 73,
    "unique_references": 72,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 54,
      "medium": 18,
      "weak": 1
    },
    "findings": [
      {
        "line": 10,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מַחְסוֹר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 47,
        "ref": "SBLGNT:Jas.1.23",
        "raw_ref": "SBLGNT:James.1.23",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 48,
        "ref": "SBLGNT:Jas.1.24",
        "raw_ref": "SBLGNT:James.1.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 49,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 50,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 55,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Job.4.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "Mishnah Avot 3:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 62,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 66,
        "ref": "SBLGNT:Jas.1.25",
        "raw_ref": "SBLGNT:James.1.25",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 71,
        "ref": "Didache 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 72,
        "ref": "Gospel of Thomas 3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "Epistle of Barnabas 18:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 421428,
    "cached_input_tokens": 368256,
    "cache_write_input_tokens": 0,
    "output_tokens": 25382,
    "reasoning_output_tokens": 13223,
    "total_tokens": 446810
  }
}
```

## 103:3 / luna / s103-20261009

```json
{
  "diagnostics": [
    {
      "call_id": "call_4e16fd501c0445e2934326dced69d239",
      "message": "Script failed"
    },
    {
      "call_id": "call_4e16fd501c0445e2934326dced69d239",
      "message": "Script error:"
    },
    {
      "call_id": "call_4e16fd501c0445e2934326dced69d239",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_d761c5b750064da29e9b94c63f8de0fb",
      "message": "Script failed"
    },
    {
      "call_id": "call_d761c5b750064da29e9b94c63f8de0fb",
      "message": "Script error:"
    },
    {
      "call_id": "call_d761c5b750064da29e9b94c63f8de0fb",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_401fd3bf73c84bc680729d77ae824727",
      "message": "Script failed"
    },
    {
      "call_id": "call_401fd3bf73c84bc680729d77ae824727",
      "message": "Script error:"
    },
    {
      "call_id": "call_401fd3bf73c84bc680729d77ae824727",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_305786e944674946820d9a48a4a2323e",
      "message": "Script failed"
    },
    {
      "call_id": "call_305786e944674946820d9a48a4a2323e",
      "message": "Script error:"
    },
    {
      "call_id": "call_305786e944674946820d9a48a4a2323e",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_df456a7a8bbe462bbae6e28915f6c938",
      "message": "Script failed"
    },
    {
      "call_id": "call_df456a7a8bbe462bbae6e28915f6c938",
      "message": "Script error:"
    },
    {
      "call_id": "call_df456a7a8bbe462bbae6e28915f6c938",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_8495b49160124fd290b9650983dddc3f",
      "message": "Script failed"
    },
    {
      "call_id": "call_8495b49160124fd290b9650983dddc3f",
      "message": "Script error:"
    },
    {
      "call_id": "call_8495b49160124fd290b9650983dddc3f",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_52a36c59770b47a3ad58c7f2cbb18998",
      "message": "Script failed"
    },
    {
      "call_id": "call_52a36c59770b47a3ad58c7f2cbb18998",
      "message": "Script error:"
    },
    {
      "call_id": "call_52a36c59770b47a3ad58c7f2cbb18998",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    },
    {
      "call_id": "call_5ffec874e7694ece9c2643fd34f75572",
      "message": "Script failed"
    },
    {
      "call_id": "call_5ffec874e7694ece9c2643fd34f75572",
      "message": "Script error:"
    },
    {
      "call_id": "call_5ffec874e7694ece9c2643fd34f75572",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv:"
    }
  ],
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/list.tsv",
    "rows": 175,
    "unique_references": 159,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 91,
      "medium": 68,
      "weak": 16
    },
    "findings": [
      {
        "line": 80,
        "ref": "2 Maccabees 7:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "Rosh Hashanah 29a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 97,
        "ref": "Mishnah Avot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Mishnah Avot 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 99,
        "ref": "Mishnah Avot 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 100,
        "ref": "Mishnah Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 101,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 103,
        "ref": "Ta'anit 23a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 104,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 105,
        "ref": "Targum Onkelos on Genesis 15:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 106,
        "ref": "Wisdom of Solomon 3:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 107,
        "ref": "SBLGNT:Jas.5.10",
        "raw_ref": "SBLGNT:James.5.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 108,
        "ref": "SBLGNT:Jas.5.11",
        "raw_ref": "SBLGNT:James.5.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 121,
        "ref": "Didache 4.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 122,
        "ref": "Didache 4.2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 123,
        "ref": "1 Clement 38.1-2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 127,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 130,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 131,
        "ref": "WLC:Ps.119.160",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 132,
        "ref": "WLC:Dan.6.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 133,
        "ref": "WLC:Deut.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 134,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 135,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 136,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 137,
        "ref": "WLC:Gen.16.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 162,
        "ref": "Mishnah Avot 3:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 163,
        "ref": "Mishnah Avot 4:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 164,
        "ref": "Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 165,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 166,
        "ref": "Wisdom of Solomon 3:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 172,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 173,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 174,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 175,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/luna/followup.tsv",
    "rows": 37,
    "unique_references": 33,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 15,
      "medium": 18,
      "weak": 4
    },
    "findings": [
      {
        "line": 24,
        "ref": "Mishnah Avot 3:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Mishnah Avot 4:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 26,
        "ref": "Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 27,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "Wisdom of Solomon 3:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 4700486,
    "cached_input_tokens": 4505344,
    "cache_write_input_tokens": 0,
    "output_tokens": 104230,
    "reasoning_output_tokens": 83949,
    "total_tokens": 4804716
  }
}
```

## 103:3 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/sol/list.tsv",
    "rows": 323,
    "unique_references": 321,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 178,
      "medium": 140,
      "weak": 5
    },
    "findings": [
      {
        "line": 4,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 4,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 5,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 6,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 8,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Isa.26.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 11,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Ezra.6.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Ezra.6.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Prov.28.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:Ps.23.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Exod.18.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Exod.18.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקים",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:Prov.8.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Ps.119.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Ps.119.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקים",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.106.30",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "WLC:Hab.2.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחסור",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "WLC:Deut.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Job.19.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 113,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 114,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 115,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 116,
        "ref": "Mishnah Avot 1:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 117,
        "ref": "Mishnah Avot 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 164,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 165,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 166,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 186,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 187,
        "ref": "WLC:Ps.27.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 189,
        "ref": "WLC:Ps.33.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 189,
        "ref": "WLC:Ps.33.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 190,
        "ref": "WLC:Ps.119.86",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 191,
        "ref": "WLC:Exod.14.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 192,
        "ref": "WLC:Isa.33.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 192,
        "ref": "WLC:Isa.33.22",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחוקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 193,
        "ref": "WLC:Eccl.4.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 193,
        "ref": "WLC:Eccl.4.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 221,
        "ref": "Makkot 24a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 221,
        "ref": "Makkot 24a",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 222,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 223,
        "ref": "Mishnah Avot 5:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 224,
        "ref": "Sirach 4:28",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 225,
        "ref": "Sirach 6:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 226,
        "ref": "Sirach 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 227,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 228,
        "ref": "1 Maccabees 2:50",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 275,
        "ref": "Didache 1:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 276,
        "ref": "1 Clement 38:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 277,
        "ref": "WLC:Ps.119.90",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 277,
        "ref": "WLC:Ps.119.90",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 278,
        "ref": "WLC:Ps.119.30",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 289,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 290,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 291,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 292,
        "ref": "Mishnah Avot 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 293,
        "ref": "Bava Metzia 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 294,
        "ref": "Wisdom of Solomon 2:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 295,
        "ref": "Wisdom of Solomon 3:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 317,
        "ref": "Ignatius, Letter to Polycarp 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 318,
        "ref": "Ignatius, Letter to Polycarp 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 319,
        "ref": "1 Clement 34:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 320,
        "ref": "Justin Martyr, First Apology 67",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 321,
        "ref": "Tertullian, Apology 39",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 322,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 323,
        "ref": "Shepherd of Hermas, Mandate 5.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/103_3/sol/followup.tsv",
    "rows": 138,
    "unique_references": 138,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 91,
      "medium": 45,
      "weak": 2
    },
    "findings": [
      {
        "line": 1,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 2,
        "ref": "WLC:Ps.27.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 4,
        "ref": "WLC:Ps.33.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 4,
        "ref": "WLC:Ps.33.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 5,
        "ref": "WLC:Ps.119.86",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 6,
        "ref": "WLC:Exod.14.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 7,
        "ref": "WLC:Isa.33.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 7,
        "ref": "WLC:Isa.33.22",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחוקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 8,
        "ref": "WLC:Eccl.4.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 8,
        "ref": "WLC:Eccl.4.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "Makkot 24a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "Makkot 24a",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "Mishnah Avot 5:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "Sirach 4:28",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Sirach 6:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "Sirach 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 43,
        "ref": "1 Maccabees 2:50",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Didache 1:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "1 Clement 38:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 92,
        "ref": "WLC:Ps.119.90",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 92,
        "ref": "WLC:Ps.119.90",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 93,
        "ref": "WLC:Ps.119.30",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 104,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 105,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 106,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 107,
        "ref": "Mishnah Avot 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "Bava Metzia 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "Wisdom of Solomon 2:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 110,
        "ref": "Wisdom of Solomon 3:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 132,
        "ref": "Ignatius, Letter to Polycarp 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 133,
        "ref": "Ignatius, Letter to Polycarp 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 134,
        "ref": "1 Clement 34:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 135,
        "ref": "Justin Martyr, First Apology 67",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 136,
        "ref": "Tertullian, Apology 39",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 137,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 138,
        "ref": "Shepherd of Hermas, Mandate 5.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 1030333,
    "cached_input_tokens": 947072,
    "cache_write_input_tokens": 0,
    "output_tokens": 41094,
    "reasoning_output_tokens": 20782,
    "total_tokens": 1071427
  }
}
```

## sec1 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec1/luna/list.tsv",
    "rows": 118,
    "unique_references": 114,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 93,
      "medium": 12,
      "weak": 13
    },
    "findings": [
      {
        "line": 25,
        "ref": "Mishnah, Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 26,
        "ref": "Mishnah, Avot 3:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 27,
        "ref": "Mishnah, Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "Babylonian Talmud, Bava Metzia 83a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 29,
        "ref": "Sirach 5:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Sirach 11:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Wisdom of Solomon 5:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "Mishnah, Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 74,
        "ref": "Wisdom of Solomon 5:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 85,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 86,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 87,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 87,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "WLC:Prov.13.25",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:Josh.1.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Prov.30.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Prov.30.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 109,
        "ref": "Tobit 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 112,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 114,
        "ref": "WLC:Deut.32.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "WLC:Deut.15.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "WLC:Deut.15.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 116,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 116,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 117,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 118,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec1/luna/followup.tsv",
    "rows": 27,
    "unique_references": 26,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 19,
      "medium": 3,
      "weak": 5
    },
    "findings": [
      {
        "line": 18,
        "ref": "Tobit 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 21,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "WLC:Deut.32.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 24,
        "ref": "WLC:Deut.15.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 24,
        "ref": "WLC:Deut.15.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 25,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 25,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 733726,
    "cached_input_tokens": 576768,
    "cache_write_input_tokens": 0,
    "output_tokens": 78540,
    "reasoning_output_tokens": 64002,
    "total_tokens": 812266
  }
}
```

## sec1 / sol / s103-20261009

```json
{
  "diagnostics": [
    {
      "call_id": "call_f39e6c670e3c46ceac1c99c67e5ba09f",
      "message": "Script failed"
    },
    {
      "call_id": "call_f39e6c670e3c46ceac1c99c67e5ba09f",
      "message": "Script error:"
    },
    {
      "call_id": "call_f39e6c670e3c46ceac1c99c67e5ba09f",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec1/sol/list.tsv:"
    }
  ],
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec1/sol/list.tsv",
    "rows": 238,
    "unique_references": 237,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 146,
      "medium": 91,
      "weak": 1
    },
    "findings": [
      {
        "line": 49,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 56,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 57,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 58,
        "ref": "SBLGNT:Jas.5.8",
        "raw_ref": "SBLGNT:James.5.8",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 97,
        "ref": "Mishnah Berakhot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 99,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 100,
        "ref": "Mishnah Avot 3:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 101,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "Wisdom of Solomon 5:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "Wisdom of Solomon 5:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 110,
        "ref": "Tobit 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 111,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 112,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 113,
        "ref": "WLC:Gen.39.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 114,
        "ref": "WLC:Gen.39.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "WLC:Dan.6.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 116,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 117,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 118,
        "ref": "WLC:Ps.111.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 119,
        "ref": "WLC:Ps.111.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 120,
        "ref": "WLC:Prov.12.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 121,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 122,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 123,
        "ref": "WLC:Eccl.1.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 124,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 125,
        "ref": "WLC:Gen.41.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 130,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 132,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 139,
        "ref": "SBLGNT:Jas.1.12",
        "raw_ref": "SBLGNT:James.1.12",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 145,
        "ref": "SBLGNT:Jas.2.15",
        "raw_ref": "SBLGNT:James.2.15",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 146,
        "ref": "SBLGNT:Jas.2.16",
        "raw_ref": "SBLGNT:James.2.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 168,
        "ref": "Sirach 29:11",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 169,
        "ref": "Sirach 29:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 170,
        "ref": "Didache 16:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 171,
        "ref": "Gregory the Great, Homilies on the Gospels 19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 172,
        "ref": "WLC:Deut.16.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 173,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 203,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 204,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 209,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 209,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 210,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 219,
        "ref": "Sirach 14:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 220,
        "ref": "Sirach 14:13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 221,
        "ref": "Tobit 4:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 222,
        "ref": "Tobit 12:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 223,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 229,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 230,
        "ref": "SBLGNT:Jas.2.24",
        "raw_ref": "SBLGNT:James.2.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 236,
        "ref": "SBLGNT:Jas.1.11",
        "raw_ref": "SBLGNT:James.1.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 238,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec1/sol/followup.tsv",
    "rows": 66,
    "unique_references": 66,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 36,
      "medium": 30
    },
    "findings": [
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 32,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "Sirach 14:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 48,
        "ref": "Sirach 14:13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "Tobit 4:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "Tobit 12:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 51,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 58,
        "ref": "SBLGNT:Jas.2.24",
        "raw_ref": "SBLGNT:James.2.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 64,
        "ref": "SBLGNT:Jas.1.11",
        "raw_ref": "SBLGNT:James.1.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 66,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 529618,
    "cached_input_tokens": 479872,
    "cache_write_input_tokens": 0,
    "output_tokens": 29884,
    "reasoning_output_tokens": 14029,
    "total_tokens": 559502
  }
}
```

## sec2 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec2/luna/list.tsv",
    "rows": 121,
    "unique_references": 121,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 91,
      "medium": 28,
      "weak": 2
    },
    "findings": [
      {
        "line": 26,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "Mishnah Berakhot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "Pirkei Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 29,
        "ref": "Pirkei Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Sirach 18:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Sirach 18:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 32,
        "ref": "Wisdom of Solomon 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 52,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 53,
        "ref": "SBLGNT:Jas.5.8",
        "raw_ref": "SBLGNT:James.5.8",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 57,
        "ref": "Mishnah Berakhot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 67,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Deut.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "Pirkei Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 70,
        "ref": "Pirkei Avot 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 71,
        "ref": "Wisdom of Solomon 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 75,
        "ref": "Didache 4.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 76,
        "ref": "Didache 8.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 81,
        "ref": "WLC:Jer.5.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 82,
        "ref": "WLC:Deut.16.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 106,
        "ref": "Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 110,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 111,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 114,
        "ref": "Didache 16.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 116,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 121,
        "ref": "Gospel of Thomas 59",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec2/luna/followup.tsv",
    "rows": 39,
    "unique_references": 39,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 32,
      "medium": 7
    },
    "findings": [
      {
        "line": 24,
        "ref": "Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 29,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 32,
        "ref": "Didache 16.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "Gospel of Thomas 59",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 599396,
    "cached_input_tokens": 512512,
    "cache_write_input_tokens": 0,
    "output_tokens": 72237,
    "reasoning_output_tokens": 59802,
    "total_tokens": 671633
  }
}
```

## sec2 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec2/sol/list.tsv",
    "rows": 190,
    "unique_references": 190,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 102,
      "medium": 79,
      "weak": 9
    },
    "findings": [
      {
        "line": 15,
        "ref": "Sirach 18:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 16,
        "ref": "Sirach 18:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 17,
        "ref": "Wisdom of Solomon 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 18,
        "ref": "Wisdom of Solomon 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 29,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 32,
        "ref": "WLC:Jer.31.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 33,
        "ref": "WLC:Jer.31.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 34,
        "ref": "WLC:Job.26.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Lev.23.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Deut.16.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:Neh.8.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Joel.2.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Isa.1.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצרה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 84,
        "ref": "WLC:Job.27.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 86,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 87,
        "ref": "WLC:Jer.33.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Job.38.33",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "WLC:Prov.8.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:Joel.1.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 97,
        "ref": "Mishnah Avot 5:21",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Mishnah Avot 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 99,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 100,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 101,
        "ref": "Shabbat 153a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "Berakhot 2a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 107,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 108,
        "ref": "SBLGNT:Jas.5.10",
        "raw_ref": "SBLGNT:James.5.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 118,
        "ref": "SBLGNT:Jas.1.11",
        "raw_ref": "SBLGNT:James.1.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 127,
        "ref": "WLC:Zech.9.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Isa.66.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 143,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 144,
        "ref": "WLC:Exod.12.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 144,
        "ref": "WLC:Exod.12.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 145,
        "ref": "WLC:Jer.33.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 146,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 149,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 153,
        "ref": "SBLGNT:Jas.4.13",
        "raw_ref": "SBLGNT:James.4.13",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 163,
        "ref": "Didache 16:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 164,
        "ref": "Didache 16:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 169,
        "ref": "WLC:Ps.81.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 170,
        "ref": "WLC:Ps.148.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 174,
        "ref": "Mishnah Berakhot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 175,
        "ref": "Mishnah Berakhot 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 176,
        "ref": "Mishnah Avot 1:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 177,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 178,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 179,
        "ref": "4 Ezra 4:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 180,
        "ref": "4 Ezra 4:36",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 188,
        "ref": "Augustine, Confessions 11.20.26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 189,
        "ref": "WLC:Ps.84.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 190,
        "ref": "Wisdom of Solomon 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec2/sol/followup.tsv",
    "rows": 60,
    "unique_references": 60,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 34,
      "medium": 24,
      "weak": 2
    },
    "findings": [
      {
        "line": 13,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Exod.12.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Exod.12.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "WLC:Jer.33.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "Mishnah Avot 4:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "SBLGNT:Jas.4.13",
        "raw_ref": "SBLGNT:James.4.13",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 33,
        "ref": "Didache 16:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "Didache 16:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "WLC:Ps.81.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Ps.148.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "Mishnah Berakhot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "Mishnah Berakhot 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 46,
        "ref": "Mishnah Avot 1:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 47,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 48,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "4 Ezra 4:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "4 Ezra 4:36",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 58,
        "ref": "Augustine, Confessions 11.20.26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 59,
        "ref": "WLC:Ps.84.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "Wisdom of Solomon 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 245846,
    "cached_input_tokens": 198656,
    "cache_write_input_tokens": 0,
    "output_tokens": 27658,
    "reasoning_output_tokens": 13879,
    "total_tokens": 273504
  }
}
```

## sec3 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec3/luna/list.tsv",
    "rows": 102,
    "unique_references": 100,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 63,
      "medium": 36,
      "weak": 3
    },
    "findings": [
      {
        "line": 11,
        "ref": "Sirach 38:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 12,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 25,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 26,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 34,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 35,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 38,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 39,
        "ref": "Ignatius, Ephesians 20:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "Mishnah Pesachim 10:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "Tobit 11:13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 52,
        "ref": "WLC:Gen.18.28",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "Ta'anit 7a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 55,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 56,
        "ref": "Sirach 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 59,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Prov.30.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Prov.30.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "SBLGNT:Jas.2.14",
        "raw_ref": "SBLGNT:James.2.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 92,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 95,
        "ref": "SBLGNT:Jas.1.12",
        "raw_ref": "SBLGNT:James.1.12",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 102,
        "ref": "WLC:Prov.30.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec3/luna/followup.tsv",
    "rows": 42,
    "unique_references": 40,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 24,
      "medium": 17,
      "weak": 1
    },
    "findings": [
      {
        "line": 3,
        "ref": "WLC:Prov.30.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 3,
        "ref": "WLC:Prov.30.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 23,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 23,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "SBLGNT:Jas.2.14",
        "raw_ref": "SBLGNT:James.2.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 32,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 35,
        "ref": "SBLGNT:Jas.1.12",
        "raw_ref": "SBLGNT:James.1.12",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 42,
        "ref": "WLC:Prov.30.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 263278,
    "cached_input_tokens": 161280,
    "cache_write_input_tokens": 0,
    "output_tokens": 57886,
    "reasoning_output_tokens": 50471,
    "total_tokens": 321164
  }
}
```

## sec3 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec3/sol/list.tsv",
    "rows": 108,
    "unique_references": 108,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 59,
      "medium": 46,
      "weak": 3
    },
    "findings": [
      {
        "line": 4,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 4,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 5,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Prov.28.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 20,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 20,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "Menachot 53b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 29,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 46,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Ps.23.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Joel.1.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "Berakhot 5a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 56,
        "ref": "Berakhot 5b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "Taanit 7a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 58,
        "ref": "Pirkei Avot 4:20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 64,
        "ref": "SBLGNT:Jas.5.11",
        "raw_ref": "SBLGNT:James.5.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 70,
        "ref": "Ignatius of Antioch, Letter to the Romans 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 79,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 96,
        "ref": "WLC:Job.7.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 97,
        "ref": "WLC:Dan.7.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 101,
        "ref": "Pirkei Avot 5:23",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "Shepherd of Hermas, Mandate 5.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec3/sol/followup.tsv",
    "rows": 36,
    "unique_references": 36,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 21,
      "medium": 14,
      "weak": 1
    },
    "findings": [
      {
        "line": 7,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 24,
        "ref": "WLC:Job.7.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 25,
        "ref": "WLC:Dan.7.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "Pirkei Avot 5:23",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "Shepherd of Hermas, Mandate 5.1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 190880,
    "cached_input_tokens": 160896,
    "cache_write_input_tokens": 0,
    "output_tokens": 21313,
    "reasoning_output_tokens": 12998,
    "total_tokens": 212193
  }
}
```

## sec4 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec4/luna/list.tsv",
    "rows": 75,
    "unique_references": 72,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 49,
      "medium": 22,
      "weak": 4
    },
    "findings": [
      {
        "line": 8,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 16,
        "ref": "Genesis Rabbah 56:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 17,
        "ref": "WLC:Jonah.2.3",
        "raw_ref": "WLC:Jon.2.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 23,
        "ref": "Mishnah Yoma 8:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 29,
        "ref": "Sirach 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Martyrdom of Polycarp 11:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "2 Maccabees 7:21",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 32,
        "ref": "4 Maccabees 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 33,
        "ref": "Wisdom 2:20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "WLC:Ps.90.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Ps.90.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱנוֹשׁ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Ps.90.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "Sirach 4:28",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 47,
        "ref": "Sirach 18:30",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "Wisdom of Solomon 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 53,
        "ref": "WLC:Job.13.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "לוֹ",
        "kind": "wording_review",
        "variant_matches": [
          {
            "after_word": 3,
            "reading": {
              "type": "x-qere",
              "text": "ל֣וֹ",
              "words": [
                {
                  "lemma": "l",
                  "morph": "HR/Sp3ms",
                  "id": "18Vvg",
                  "text": "ל֣וֹ"
                }
              ]
            }
          }
        ],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 70,
        "ref": "b. Shabbat 88b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "Berakhot 60b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 74,
        "ref": "4 Maccabees 6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec4/luna/followup.tsv",
    "rows": 19,
    "unique_references": 18,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 16,
      "medium": 3
    },
    "findings": [
      {
        "line": 14,
        "ref": "b. Shabbat 88b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 17,
        "ref": "Berakhot 60b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 18,
        "ref": "4 Maccabees 6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "first_turn_repair": {
    "policy": "bible-first-turn-repair-v1",
    "approval": "Accepted by the Claude Code Bible orchestrator (fork of the 2026-10-09 enrichment session) under the user's production go for S103; locator-only correction verified against the local WLC/SBLGNT/KJV text; no grade, kind, basis or explanation changed; listed for the user's review in the S103 Bible audit README.",
    "tool_audit_reviewed": true,
    "accepted_at": "2026-10-09T05:41:54.143992+00:00",
    "changes": [
      {
        "line": 49,
        "before": [
          "medium",
          "tevrat",
          "motif",
          "WLC:Wisd.3.1",
          "the righteous held in God's hand",
          "The commentary cites the soul as pledged for what it earns; Wisdom says the souls of the righteous are in God's hand and no torment touches them. It turns being held from punitive custody into protection, qualifying a simple reading of captivity."
        ],
        "after": [
          "medium",
          "tevrat",
          "motif",
          "Wisdom of Solomon 3:1",
          "the righteous held in God's hand",
          "The commentary cites the soul as pledged for what it earns; Wisdom says the souls of the righteous are in God's hand and no torment touches them. It turns being held from punitive custody into protection, qualifying a simple reading of captivity."
        ],
        "reason": "The Wisdom of Solomon is not in the WLC edition; the row names the work itself (KJV Apocrypha Wis 3:1 checked as finding aid), as in the approved S87 wave2 correction"
      }
    ],
    "model_calls": 0,
    "artifacts": {
      "turn1.original.tsv": "5b865de5b60d6249f3e7aa1dbdf1ef6640de1b079c4ec2bcddcf4df75b712bab",
      "turn1.validation.failed.json": "af9ad9a909227a017f25b61e1ea7e39b5ba389efc06a508988bae87ee331d418",
      "turn1.tool_calls.json": "971c553021a5a6814720bf3eb235c7eb4a72d70252da90708062787b4b550729",
      "turn1.repair.proposed.json": "910c27c9666a9dfc8e6f1e7c6b95a4c8173b54175580bfcba0a072cf34260391",
      "turn1.repair.proposed.tsv": "9af268859a146632d290ce72910b8812f996957d787aca3ee1ed1349fa321b32",
      "turn1.accepted.tsv": "9af268859a146632d290ce72910b8812f996957d787aca3ee1ed1349fa321b32"
    }
  },
  "usage_tokens": {
    "input_tokens": 419435,
    "cached_input_tokens": 277760,
    "cache_write_input_tokens": 0,
    "output_tokens": 74812,
    "reasoning_output_tokens": 66771,
    "total_tokens": 494247
  }
}
```

## sec4 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec4/sol/list.tsv",
    "rows": 205,
    "unique_references": 205,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 140,
      "medium": 65
    },
    "findings": [
      {
        "line": 6,
        "ref": "WLC:Job.4.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 6,
        "ref": "WLC:Job.4.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "Mishnah Ketubot 4:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "Protevangelium of James 8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "WLC:Joel.2.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Deut.16.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:2Kgs.17.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:2Kgs.17.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Jer.33.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Jer.33.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 62,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 71,
        "ref": "WLC:Job.27.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 73,
        "ref": "WLC:Zech.9.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 75,
        "ref": "WLC:Gen.16.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 75,
        "ref": "WLC:Gen.16.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 77,
        "ref": "WLC:Isa.1.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 77,
        "ref": "WLC:Isa.1.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצרה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 78,
        "ref": "WLC:Lev.23.36",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "Mishnah Ta'anit 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 89,
        "ref": "Didache 8:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "Didache 1:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 92,
        "ref": "1 Clement 38:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 94,
        "ref": "SBLGNT:Jas.2.16",
        "raw_ref": "SBLGNT:James.2.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 102,
        "ref": "SBLGNT:Jas.5.12",
        "raw_ref": "SBLGNT:James.5.12",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 106,
        "ref": "SBLGNT:Jas.5.10",
        "raw_ref": "SBLGNT:James.5.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 107,
        "ref": "SBLGNT:Jas.5.11",
        "raw_ref": "SBLGNT:James.5.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 124,
        "ref": "2 Maccabees 7:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 125,
        "ref": "2 Maccabees 7:20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 146,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 146,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 147,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 147,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 153,
        "ref": "SBLGNT:Jas.1.19",
        "raw_ref": "SBLGNT:James.1.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 168,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 169,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 178,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 179,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 184,
        "ref": "Shepherd of Hermas, Similitude 5.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 185,
        "ref": "Berakhot 6b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 186,
        "ref": "Tobit 4:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 187,
        "ref": "Tobit 4:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 188,
        "ref": "Sirach 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 189,
        "ref": "Sirach 18:30",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 190,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 191,
        "ref": "Wisdom of Solomon 2:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 192,
        "ref": "Wisdom of Solomon 2:20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 193,
        "ref": "4 Maccabees 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec4/sol/followup.tsv",
    "rows": 80,
    "unique_references": 80,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 60,
      "medium": 20
    },
    "findings": [
      {
        "line": 21,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 28,
        "ref": "SBLGNT:Jas.1.19",
        "raw_ref": "SBLGNT:James.1.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 43,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 54,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 59,
        "ref": "Shepherd of Hermas, Similitude 5.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 60,
        "ref": "Berakhot 6b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 61,
        "ref": "Tobit 4:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 62,
        "ref": "Tobit 4:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Sirach 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 64,
        "ref": "Sirach 18:30",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 65,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 66,
        "ref": "Wisdom of Solomon 2:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 67,
        "ref": "Wisdom of Solomon 2:20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 68,
        "ref": "4 Maccabees 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 361892,
    "cached_input_tokens": 315776,
    "cache_write_input_tokens": 0,
    "output_tokens": 35823,
    "reasoning_output_tokens": 20589,
    "total_tokens": 397715
  }
}
```

## sec5 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec5/luna/list.tsv",
    "rows": 126,
    "unique_references": 126,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 110,
      "medium": 16
    },
    "findings": [
      {
        "line": 5,
        "ref": "WLC:Ps.91.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 59,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Dan.6.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Hab.2.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Esth.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Esth.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Deut.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Deut.4.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Deut.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Ps.23.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:Prov.10.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:Prov.10.21",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 71,
        "ref": "Wisdom of Solomon 10:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 72,
        "ref": "Wisdom of Solomon 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "2 Maccabees 7:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 74,
        "ref": "Babylonian Talmud, Makkot 10a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 75,
        "ref": "Babylonian Talmud, Sotah 37a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 76,
        "ref": "Babylonian Talmud, Berakhot 60b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 77,
        "ref": "Augustine, City of God 15.26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 97,
        "ref": "Sirach 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 99,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 100,
        "ref": "Genesis Rabbah 32:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 101,
        "ref": "1 Clement 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "Shepherd of Hermas, Vision 3 (tower vision)",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec5/luna/followup.tsv",
    "rows": 48,
    "unique_references": 48,
    "schema_errors": [
      "line 38: unknown verse in specified edition: SBLGNT:Jude.3"
    ],
    "duplicates": [],
    "strengths": {
      "strong": 47,
      "medium": 1
    },
    "findings": [
      {
        "line": 20,
        "ref": "Sirach 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 21,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 22,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "Genesis Rabbah 32:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 24,
        "ref": "1 Clement 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Shepherd of Hermas, Vision 3 (tower vision)",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "repair": {
    "approval": "Accepted by the Claude Code Bible orchestrator (fork of the 2026-10-09 enrichment session) under the user's production go for S103; locator-only correction verified against the local WLC/SBLGNT/KJV text; no grade, kind, basis or explanation changed; listed for the user's review in the S103 Bible audit README.",
    "accepted_at": "2026-10-09T05:41:55.333615+00:00",
    "changes": [
      {
        "line": 38,
        "before": [
          "strong",
          "incil",
          "motif",
          "SBLGNT:Jude.3",
          "contend for the delivered faith",
          "The commentary calls truth something to be guarded; Jude urges believers to contend for the faith once delivered to the saints, giving that protection a communal action."
        ],
        "after": [
          "strong",
          "incil",
          "motif",
          "SBLGNT:Jude.1.3",
          "contend for the delivered faith",
          "The commentary calls truth something to be guarded; Jude urges believers to contend for the faith once delivered to the saints, giving that protection a communal action."
        ],
        "reason": "Jude has one chapter; SBLGNT numbers the cited verse Jude.1.3 (contend for the faith once delivered); checked locally"
      }
    ],
    "raw_sha256": "db3157c1fadf38cc491ef0f55c77bf284bd2d4d73f80f97855aac0662f6f1aa5",
    "accepted_sha256": "b9a4ec26aeebc9467ba807b33e45f24c56a0bbfe3f98381167e13220c52157df",
    "proposal_sha256": "e3d0e01ba2cf6ff310fbfffdab12dac468bd4f5919f6a3b20cc963682b500fa0",
    "failed_log_sha256": "d46058790bec7c912f78277f882218ba7fb8a497e1d48442e413b53713d8e5ef",
    "model_calls": 0,
    "policy": "Raw proposals, failed validation and failed log preserved; no regrading."
  },
  "usage_tokens": {
    "input_tokens": 306767,
    "cached_input_tokens": 189952,
    "cache_write_input_tokens": 0,
    "output_tokens": 66349,
    "reasoning_output_tokens": 57793,
    "total_tokens": 373116
  }
}
```

## sec5 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec5/sol/list.tsv",
    "rows": 238,
    "unique_references": 238,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 167,
      "medium": 70,
      "weak": 1
    },
    "findings": [
      {
        "line": 18,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Gen.15.6",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 20,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 20,
        "ref": "WLC:Hab.2.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "WLC:Ps.78.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:Ps.23.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Isa.33.22",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Isa.33.22",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Isa.54.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Isa.54.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Dan.5.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 99,
        "ref": "Makkot 10a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 100,
        "ref": "Bava Kamma 60a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 101,
        "ref": "Shabbat 54b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "1 Clement 12:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 103,
        "ref": "WLC:Gen.41.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 103,
        "ref": "WLC:Gen.41.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 105,
        "ref": "WLC:Deut.32.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 105,
        "ref": "WLC:Deut.32.36",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 106,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 106,
        "ref": "WLC:Josh.1.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 107,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 107,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 108,
        "ref": "WLC:Deut.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 108,
        "ref": "WLC:Deut.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 109,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 109,
        "ref": "WLC:Prov.28.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Isa.49.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "WLC:Isa.49.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 128,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 142,
        "ref": "Ignatius of Antioch, To the Ephesians 9:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 143,
        "ref": "Targum Psalms 91:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 144,
        "ref": "Sotah 21a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 145,
        "ref": "WLC:Dan.6.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 145,
        "ref": "WLC:Dan.6.29",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 171,
        "ref": "WLC:Dan.6.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 171,
        "ref": "WLC:Dan.6.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 172,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 172,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 173,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 173,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 174,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 174,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 188,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 189,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 207,
        "ref": "Mishnah Makkot 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 208,
        "ref": "Shabbat 55a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 209,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 210,
        "ref": "Sirach 4:28",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 211,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 211,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 212,
        "ref": "WLC:Job.19.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 212,
        "ref": "WLC:Job.19.23",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 233,
        "ref": "Mishnah Makkot 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 234,
        "ref": "Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 235,
        "ref": "Augustine, City of God 15.26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 236,
        "ref": "Justin Martyr, Dialogue with Trypho 138",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 237,
        "ref": "Wisdom of Solomon 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 238,
        "ref": "Sirach 2:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec5/sol/followup.tsv",
    "rows": 93,
    "unique_references": 93,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 65,
      "medium": 28
    },
    "findings": [
      {
        "line": 26,
        "ref": "WLC:Dan.6.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:Dan.6.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "WLC:Ps.34.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 28,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 28,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 44,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 62,
        "ref": "Mishnah Makkot 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Shabbat 55a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 64,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 65,
        "ref": "Sirach 4:28",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 66,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Job.19.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Job.19.23",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "Mishnah Makkot 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 89,
        "ref": "Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Augustine, City of God 15.26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "Justin Martyr, Dialogue with Trypho 138",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 92,
        "ref": "Wisdom of Solomon 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 93,
        "ref": "Sirach 2:10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 190329,
    "cached_input_tokens": 114304,
    "cache_write_input_tokens": 0,
    "output_tokens": 32008,
    "reasoning_output_tokens": 17557,
    "total_tokens": 222337
  }
}
```

## sec6 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec6/luna/list.tsv",
    "rows": 83,
    "unique_references": 83,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 67,
      "medium": 15,
      "weak": 1
    },
    "findings": [
      {
        "line": 13,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Job.36.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חשר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Job.36.29",
        "field": "note",
        "language": "Hebrew",
        "wording": "חשר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "WLC:Ps.23.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Deut.28.48",
        "field": "basis",
        "language": "Hebrew",
        "wording": "מחסור",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Deut.28.48",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Gen.41.49",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Gen.47.26",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Gen.47.26",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "Pirkei Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "WLC:Lev.23.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Lev.23.36",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec6/luna/followup.tsv",
    "rows": 36,
    "unique_references": 36,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 29,
      "medium": 7
    },
    "findings": [
      {
        "line": 16,
        "ref": "WLC:Lev.23.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Lev.23.36",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 425473,
    "cached_input_tokens": 321280,
    "cache_write_input_tokens": 0,
    "output_tokens": 55155,
    "reasoning_output_tokens": 47188,
    "total_tokens": 480628
  }
}
```

## sec6 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec6/sol/list.tsv",
    "rows": 191,
    "unique_references": 188,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 152,
      "medium": 36,
      "weak": 3
    },
    "findings": [
      {
        "line": 9,
        "ref": "WLC:Gen.41.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Gen.41.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Gen.41.49",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Deut.11.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Deut.11.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "WLC:Jer.5.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 21,
        "ref": "WLC:Jer.5.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 27,
        "ref": "SBLGNT:Jas.5.18",
        "raw_ref": "SBLGNT:James.5.18",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 28,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 63,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחסור",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Job.28.26",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 70,
        "ref": "WLC:2Chr.7.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 70,
        "ref": "WLC:2Chr.7.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 72,
        "ref": "WLC:2Sam.22.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חשר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 72,
        "ref": "WLC:2Sam.22.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "חשר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "SBLGNT:Jas.1.10",
        "raw_ref": "SBLGNT:James.1.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 92,
        "ref": "SBLGNT:Jas.1.11",
        "raw_ref": "SBLGNT:James.1.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 104,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 104,
        "ref": "WLC:Job.27.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 105,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 105,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "WLC:Exod.16.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "WLC:Exod.16.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "Mishnah Ta'anit 3:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 131,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 167,
        "ref": "SBLGNT:Jas.5.5",
        "raw_ref": "SBLGNT:James.5.5",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 172,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 173,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 174,
        "ref": "Taanit 5b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 179,
        "ref": "WLC:Deut.8.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 179,
        "ref": "WLC:Deut.8.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 190,
        "ref": "Mishnah Ta'anit 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec6/sol/followup.tsv",
    "rows": 57,
    "unique_references": 56,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 41,
      "medium": 16
    },
    "findings": [
      {
        "line": 33,
        "ref": "SBLGNT:Jas.5.5",
        "raw_ref": "SBLGNT:James.5.5",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 38,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Taanit 5b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "WLC:Deut.8.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Deut.8.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "Mishnah Ta'anit 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 306525,
    "cached_input_tokens": 263296,
    "cache_write_input_tokens": 0,
    "output_tokens": 33766,
    "reasoning_output_tokens": 19619,
    "total_tokens": 340291
  }
}
```

## sec7 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec7/luna/list.tsv",
    "rows": 148,
    "unique_references": 147,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 115,
      "medium": 31,
      "weak": 2
    },
    "findings": [
      {
        "line": 44,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Gen.15.6",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Deut.32.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Dan.6.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Ps.8.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "WLC:Gen.31.42",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Eccl.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Gen.24.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 70,
        "ref": "Sirach 33:25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 71,
        "ref": "Sirach 6:25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 72,
        "ref": "Wisdom of Solomon 9:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "Bava Metzia 32a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 74,
        "ref": "Mishnah, Avot 3:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 75,
        "ref": "4 Ezra 7:6-9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 103,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 104,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 105,
        "ref": "SBLGNT:Jas.2.24",
        "raw_ref": "SBLGNT:James.2.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 108,
        "ref": "Sirach 38:25-26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 116,
        "ref": "WLC:Num.12.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 117,
        "ref": "WLC:Isa.53.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "Sirach 6:30",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 127,
        "ref": "Mishnah, Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 128,
        "ref": "1QS 3:20-4:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 129,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 130,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 148,
        "ref": "Augustine, Confessions 13.9.10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec7/luna/followup.tsv",
    "rows": 40,
    "unique_references": 40,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 38,
      "weak": 1,
      "medium": 1
    },
    "findings": [
      {
        "line": 8,
        "ref": "WLC:Num.12.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Isa.53.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "Sirach 6:30",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 19,
        "ref": "Mishnah, Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 20,
        "ref": "1QS 3:20-4:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 21,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 22,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 40,
        "ref": "Augustine, Confessions 13.9.10",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 348756,
    "cached_input_tokens": 276736,
    "cache_write_input_tokens": 0,
    "output_tokens": 55918,
    "reasoning_output_tokens": 44476,
    "total_tokens": 404674
  }
}
```

## sec7 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec7/sol/list.tsv",
    "rows": 203,
    "unique_references": 201,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 124,
      "medium": 79
    },
    "findings": [
      {
        "line": 46,
        "ref": "WLC:Job.5.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Josh.1.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Jer.12.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Jer.12.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 52,
        "ref": "WLC:Gen.24.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "WLC:Gen.24.40",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "WLC:Ps.37.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Deut.1.32",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Ps.119.30",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Isa.26.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:2Chr.20.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Ps.119.33",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Exod.5.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Exod.5.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "חק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Ps.90.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Eccl.5.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 92,
        "ref": "Bava Metzia 32b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 93,
        "ref": "Exodus Rabbah 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 94,
        "ref": "Bava Metzia 85a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 95,
        "ref": "Berakhot 40a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 96,
        "ref": "Sirach 33:25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 97,
        "ref": "Pirkei Avot 3:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Sirach 6:25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 124,
        "ref": "WLC:Ps.119.54",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 125,
        "ref": "WLC:Job.28.26",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "WLC:Prov.30.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "WLC:Prov.30.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "חק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:Dan.6.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Dan.6.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Dan.6.29",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Ps.118.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Ps.118.25",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 149,
        "ref": "Didache 16:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 187,
        "ref": "Shabbat 128b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 188,
        "ref": "Bava Metzia 32b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 189,
        "ref": "Sirach 6:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 190,
        "ref": "Sirach 51:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 191,
        "ref": "Sirach 51:27",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 199,
        "ref": "Gospel of Thomas 90",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec7/sol/followup.tsv",
    "rows": 54,
    "unique_references": 54,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 26,
      "medium": 28
    },
    "findings": [
      {
        "line": 38,
        "ref": "Shabbat 128b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "Bava Metzia 32b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Sirach 6:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "Sirach 51:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "Sirach 51:27",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "Gospel of Thomas 90",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 415544,
    "cached_input_tokens": 353920,
    "cache_write_input_tokens": 0,
    "output_tokens": 33219,
    "reasoning_output_tokens": 19274,
    "total_tokens": 448763
  }
}
```

## sec8 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec8/luna/list.tsv",
    "rows": 147,
    "unique_references": 129,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 78,
      "medium": 65,
      "weak": 4
    },
    "findings": [
      {
        "line": 43,
        "ref": "Didache 11.8-12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 46,
        "ref": "WLC:Gen.42.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Gen.42.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Gen.45.26",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Gen.45.26",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Exod.4.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Exod.4.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Exod.14.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Exod.14.31",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Gen.15.6",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Prov.12.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Deut.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 56,
        "ref": "WLC:Deut.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "נאמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Num.12.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Dan.6.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Dan.6.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "מהימן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Hab.2.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Job.4.17",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Job.14.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Job.14.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Eccl.2.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "Targum Onkelos, Genesis 15:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 64,
        "ref": "Targum Onkelos, Genesis 15:6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "הימן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "Targum Onkelos, Genesis 15:6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "Targum Onkelos, Genesis 15:6",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "Genesis Rabbah 56:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 66,
        "ref": "Mishnah Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 67,
        "ref": "Babylonian Talmud, Makkot 24a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 68,
        "ref": "1QS 5:24-25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 69,
        "ref": "Sirach 2:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 70,
        "ref": "Sirach 2:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 82,
        "ref": "Didache 15.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 85,
        "ref": "Augustine, Tractates on John 121",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 86,
        "ref": "Mishnah Avot 5:21",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "Mishnah Sanhedrin 5:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "Susanna (Theodotion) 51-59",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 110,
        "ref": "Sirach 27:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 111,
        "ref": "Sirach 27:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 112,
        "ref": "Sirach 27:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 124,
        "ref": "WLC:Exod.4.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 124,
        "ref": "WLC:Exod.4.31",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 125,
        "ref": "WLC:Deut.1.32",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 125,
        "ref": "WLC:Deut.1.32",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:2Chr.20.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Ps.89.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Ps.89.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 130,
        "ref": "WLC:Ps.27.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 130,
        "ref": "WLC:Ps.27.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 131,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 133,
        "ref": "WLC:Ps.90.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 133,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 146,
        "ref": "Sirach 27:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec8/luna/followup.tsv",
    "rows": 59,
    "unique_references": 48,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 35,
      "medium": 23,
      "weak": 1
    },
    "findings": [
      {
        "line": 20,
        "ref": "Mishnah Sanhedrin 5:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 21,
        "ref": "Susanna (Theodotion) 51-59",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 22,
        "ref": "Sirach 27:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "Sirach 27:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 24,
        "ref": "Sirach 27:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "WLC:Exod.4.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 36,
        "ref": "WLC:Exod.4.31",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:Deut.1.32",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 37,
        "ref": "WLC:Deut.1.32",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:2Chr.20.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.89.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.89.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמונה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.27.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.27.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Ps.90.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Ps.90.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "Sirach 27:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 745205,
    "cached_input_tokens": 563456,
    "cache_write_input_tokens": 0,
    "output_tokens": 101836,
    "reasoning_output_tokens": 84045,
    "total_tokens": 847041
  }
}
```

## sec8 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec8/sol/list.tsv",
    "rows": 201,
    "unique_references": 201,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 127,
      "medium": 72,
      "weak": 2
    },
    "findings": [
      {
        "line": 47,
        "ref": "SBLGNT:Jas.1.23",
        "raw_ref": "SBLGNT:James.1.23",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 48,
        "ref": "SBLGNT:Jas.1.25",
        "raw_ref": "SBLGNT:James.1.25",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 49,
        "ref": "SBLGNT:Jas.2.18",
        "raw_ref": "SBLGNT:James.2.18",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 50,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 57,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Exod.14.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Exod.4.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Exod.4.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Isa.43.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Ps.27.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 64,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 65,
        "ref": "WLC:Ps.116.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 69,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 71,
        "ref": "WLC:Job.5.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 72,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 73,
        "ref": "WLC:Deut.4.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 74,
        "ref": "WLC:Deut.6.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 75,
        "ref": "WLC:Ps.119.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 76,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "SBLGNT:Jas.5.10",
        "raw_ref": "SBLGNT:James.5.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 87,
        "ref": "Genesis Rabbah 84:21",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 88,
        "ref": "Augustine, Tractates on the Gospel of John 121.5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 89,
        "ref": "Gregory the Great, Homilies on the Gospels 26.7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 126,
        "ref": "WLC:Job.7.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:Deut.32.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Ps.119.83",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 137,
        "ref": "Mishnah Sanhedrin 5:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 138,
        "ref": "Mishnah Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 139,
        "ref": "WLC:Job.19.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 142,
        "ref": "WLC:Exod.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 143,
        "ref": "WLC:Exod.4.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 150,
        "ref": "WLC:Isa.53.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 151,
        "ref": "WLC:Num.14.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 152,
        "ref": "WLC:Ps.78.32",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 153,
        "ref": "WLC:Ps.119.66",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 154,
        "ref": "WLC:Neh.8.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 157,
        "ref": "WLC:Eccl.8.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 159,
        "ref": "WLC:Ps.119.155",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 178,
        "ref": "SBLGNT:Jas.1.24",
        "raw_ref": "SBLGNT:James.1.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 188,
        "ref": "WLC:Ps.9.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 189,
        "ref": "WLC:Job.15.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 190,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 191,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 193,
        "ref": "WLC:Isa.24.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 194,
        "ref": "WLC:Job.38.33",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 201,
        "ref": "Mishnah Avot 3:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec8/sol/followup.tsv",
    "rows": 61,
    "unique_references": 61,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 41,
      "medium": 20
    },
    "findings": [
      {
        "line": 2,
        "ref": "WLC:Exod.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 3,
        "ref": "WLC:Exod.4.31",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Isa.53.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 11,
        "ref": "WLC:Num.14.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:Ps.78.32",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Ps.119.66",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Neh.8.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Eccl.8.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 19,
        "ref": "WLC:Ps.119.155",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "SBLGNT:Jas.1.24",
        "raw_ref": "SBLGNT:James.1.24",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 48,
        "ref": "WLC:Ps.9.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Job.15.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "WLC:Isa.24.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Job.38.33",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "Mishnah Avot 3:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 247909,
    "cached_input_tokens": 200576,
    "cache_write_input_tokens": 0,
    "output_tokens": 27142,
    "reasoning_output_tokens": 15116,
    "total_tokens": 275051
  }
}
```

## sec9 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec9/luna/list.tsv",
    "rows": 143,
    "unique_references": 139,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 119,
      "medium": 23,
      "weak": 1
    },
    "findings": [
      {
        "line": 27,
        "ref": "WLC:Job.14.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "WLC:Job.14.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "Mishnah Avot 1:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Avot de-Rabbi Natan A 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 32,
        "ref": "Babylonian Talmud, Eruvin 13b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 33,
        "ref": "Babylonian Talmud, Ta'anit 22a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "Babylonian Talmud, Shevuot 39a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 35,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "Mishnah Avot 5:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "Babylonian Talmud, Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "Sifra, Kedoshim 4:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Didache 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 59,
        "ref": "SBLGNT:Jas.3.18",
        "raw_ref": "SBLGNT:James.3.18",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 72,
        "ref": "1 Clement 54:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 78,
        "ref": "WLC:Deut.6.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 78,
        "ref": "WLC:Deut.6.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 82,
        "ref": "WLC:Job.14.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 82,
        "ref": "WLC:Job.14.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Deut.16.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 84,
        "ref": "Mishnah Avot 1:18",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 85,
        "ref": "Babylonian Talmud, Berakhot 64a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "1 Clement 46:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 113,
        "ref": "Mishnah Sanhedrin 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 114,
        "ref": "Mishnah Avot 3:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 115,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 116,
        "ref": "Babylonian Talmud, Yevamot 14b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 117,
        "ref": "Babylonian Talmud, Yoma 9b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 118,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 119,
        "ref": "Sirach 28:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 120,
        "ref": "Sirach 28:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 137,
        "ref": "Didache 14:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 138,
        "ref": "1 Clement 49:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 139,
        "ref": "Gospel of Thomas 25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 142,
        "ref": "Babylonian Talmud, Bava Metzia 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 143,
        "ref": "Sirach 6:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec9/luna/followup.tsv",
    "rows": 50,
    "unique_references": 50,
    "schema_errors": [
      "line 10: unknown verse in specified edition: WLC:Ps.120.8"
    ],
    "duplicates": [],
    "strengths": {
      "strong": 46,
      "medium": 4
    },
    "findings": [
      {
        "line": 21,
        "ref": "Mishnah Sanhedrin 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 22,
        "ref": "Mishnah Avot 3:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "Babylonian Talmud, Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 24,
        "ref": "Babylonian Talmud, Yevamot 14b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Babylonian Talmud, Yoma 9b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 26,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 27,
        "ref": "Sirach 28:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 28,
        "ref": "Sirach 28:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "Didache 14:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 46,
        "ref": "1 Clement 49:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 47,
        "ref": "Gospel of Thomas 25",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 50,
        "ref": "Babylonian Talmud, Bava Metzia 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 51,
        "ref": "Sirach 6:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "repair": {
    "approval": "Accepted by the Claude Code Bible orchestrator (fork of the 2026-10-09 enrichment session) under the user's production go for S103; locator-only correction verified against the local WLC/SBLGNT/KJV text; no grade, kind, basis or explanation changed; listed for the user's review in the S103 Bible audit README.",
    "accepted_at": "2026-10-09T05:41:54.735527+00:00",
    "changes": [
      {
        "line": 10,
        "before": [
          "strong",
          "tevrat",
          "motif",
          "WLC:Ps.120.8",
          "peace offered but met with war",
          "The speaker says he is for peace while those around him want war; this preserves a counter-case to the commentary's hopeful passage from mutual speech to peace."
        ],
        "after": [
          "strong",
          "tevrat",
          "motif",
          "WLC:Ps.120.7",
          "peace offered but met with war",
          "The speaker says he is for peace while those around him want war; this preserves a counter-case to the commentary's hopeful passage from mutual speech to peace."
        ],
        "reason": "Psalm 120 has seven verses; the cited words (I am for peace, they are for war) are WLC and KJV Psalm 120:7; checked locally"
      }
    ],
    "raw_sha256": "daef2edcf421ecc192c8fefe648d2bb97b23cd1b38b63817d93cc26fde7a3420",
    "accepted_sha256": "c107f2c0837fa7c25edf0024847e14b8204a5b07f4ea117b7392bfdc94d55d8a",
    "proposal_sha256": "577ea18969f7cdb7d0c8d31cb186569a49a4030cf24d0f40dc57610f7038da6e",
    "failed_log_sha256": "7c0a4d66341862dd5384facf6bd64376dae190f4fb92962b47004ea4526165d4",
    "model_calls": 0,
    "policy": "Raw proposals, failed validation and failed log preserved; no regrading."
  },
  "usage_tokens": {
    "input_tokens": 333281,
    "cached_input_tokens": 188928,
    "cache_write_input_tokens": 0,
    "output_tokens": 73014,
    "reasoning_output_tokens": 60992,
    "total_tokens": 406295
  }
}
```

## sec9 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec9/sol/list.tsv",
    "rows": 208,
    "unique_references": 208,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 100,
      "medium": 94,
      "weak": 14
    },
    "findings": [
      {
        "line": 51,
        "ref": "SBLGNT:Jas.3.18",
        "raw_ref": "SBLGNT:James.3.18",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 52,
        "ref": "SBLGNT:Jas.4.1",
        "raw_ref": "SBLGNT:James.4.1",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 59,
        "ref": "Mishnah Avot 1:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 60,
        "ref": "Avot de-Rabbi Nathan A 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 61,
        "ref": "Babylonian Talmud, Sanhedrin 6b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 62,
        "ref": "Sirach 28:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Babylonian Talmud, Eruvin 13b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 64,
        "ref": "Didache 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 65,
        "ref": "Didache 14:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "SBLGNT:Jas.3.17",
        "raw_ref": "SBLGNT:James.3.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 110,
        "ref": "SBLGNT:Jas.3.16",
        "raw_ref": "SBLGNT:James.3.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 111,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 112,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 132,
        "ref": "Mishnah Avot 5:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 133,
        "ref": "Babylonian Talmud, Yevamot 14b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 134,
        "ref": "Genesis Rabbah 8:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 135,
        "ref": "Babylonian Talmud, Yevamot 65b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 136,
        "ref": "1 Clement 46:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 137,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 138,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 139,
        "ref": "WLC:Isa.51.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 140,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 142,
        "ref": "WLC:Jer.12.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 142,
        "ref": "WLC:Jer.12.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 143,
        "ref": "WLC:Joel.1.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 143,
        "ref": "WLC:Joel.1.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 144,
        "ref": "WLC:Isa.1.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 144,
        "ref": "WLC:Isa.1.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 145,
        "ref": "WLC:Amos.5.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 145,
        "ref": "WLC:Amos.5.21",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 146,
        "ref": "WLC:Ezra.6.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 169,
        "ref": "SBLGNT:Jas.2.15",
        "raw_ref": "SBLGNT:James.2.15",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 170,
        "ref": "SBLGNT:Jas.2.16",
        "raw_ref": "SBLGNT:James.2.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 171,
        "ref": "SBLGNT:Jas.5.16",
        "raw_ref": "SBLGNT:James.5.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 176,
        "ref": "Babylonian Talmud, Kiddushin 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 177,
        "ref": "Babylonian Talmud, Bava Metzia 84a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 178,
        "ref": "Babylonian Talmud, Ta'anit 23a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 179,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 180,
        "ref": "Didache 15:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 181,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 191,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 200,
        "ref": "SBLGNT:Jas.1.19",
        "raw_ref": "SBLGNT:James.1.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 202,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 203,
        "ref": "Babylonian Talmud, Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 204,
        "ref": "Didache 2:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 205,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 205,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 206,
        "ref": "WLC:Ps.90.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 208,
        "ref": "Testament of Gad 6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec9/sol/followup.tsv",
    "rows": 62,
    "unique_references": 62,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 35,
      "medium": 23,
      "weak": 4
    },
    "findings": [
      {
        "line": 23,
        "ref": "SBLGNT:Jas.2.15",
        "raw_ref": "SBLGNT:James.2.15",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 24,
        "ref": "SBLGNT:Jas.2.16",
        "raw_ref": "SBLGNT:James.2.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 25,
        "ref": "SBLGNT:Jas.5.16",
        "raw_ref": "SBLGNT:James.5.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 30,
        "ref": "Babylonian Talmud, Kiddushin 30b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Babylonian Talmud, Bava Metzia 84a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 32,
        "ref": "Babylonian Talmud, Ta'anit 23a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 33,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "Didache 15:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 35,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "Sirach 6:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 54,
        "ref": "SBLGNT:Jas.1.19",
        "raw_ref": "SBLGNT:James.1.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 56,
        "ref": "Mishnah Avot 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "Babylonian Talmud, Shabbat 127a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 58,
        "ref": "Didache 2:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 59,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 60,
        "ref": "WLC:Ps.90.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "Testament of Gad 6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 306918,
    "cached_input_tokens": 267648,
    "cache_write_input_tokens": 0,
    "output_tokens": 29327,
    "reasoning_output_tokens": 14452,
    "total_tokens": 336245
  }
}
```

## sec10 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec10/luna/list.tsv",
    "rows": 95,
    "unique_references": 94,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 56,
      "medium": 38,
      "weak": 1
    },
    "findings": [
      {
        "line": 9,
        "ref": "WLC:Num.27.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֻקַּת מִשְׁפָּט",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Ps.89.2",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱמוּנָה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "Tobit 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "Mishnah Avot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "Babylonian Talmud, Bava Batra 147b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 43,
        "ref": "Testament of Job 46–53",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 44,
        "ref": "2 Maccabees 7:29",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Babylonian Talmud, Pesahim 56a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 83,
        "ref": "WLC:Ps.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 86,
        "ref": "WLC:Dan.6.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "מְהֵימַן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 87,
        "ref": "Mishnah, Shevuot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 88,
        "ref": "Genesis Rabbah 98:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 94,
        "ref": "1 Clement 44:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec10/luna/followup.tsv",
    "rows": 42,
    "unique_references": 42,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 23,
      "medium": 18,
      "weak": 1
    },
    "findings": [
      {
        "line": 10,
        "ref": "Babylonian Talmud, Pesahim 56a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "WLC:Ps.2.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 33,
        "ref": "WLC:Dan.6.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "מְהֵימַן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 34,
        "ref": "Mishnah, Shevuot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 35,
        "ref": "Genesis Rabbah 98:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "1 Clement 44:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 323695,
    "cached_input_tokens": 254208,
    "cache_write_input_tokens": 0,
    "output_tokens": 57191,
    "reasoning_output_tokens": 49121,
    "total_tokens": 380886
  }
}
```

## sec10 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec10/sol/list.tsv",
    "rows": 169,
    "unique_references": 169,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 80,
      "medium": 86,
      "weak": 3
    },
    "findings": [
      {
        "line": 22,
        "ref": "WLC:Num.27.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:Num.27.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֻקַּת",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "WLC:Num.27.11",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 33,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Gen.15.6",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Hab.2.4",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱמוּנָה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Deut.6.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Deut.6.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֻקִּים",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 48,
        "ref": "WLC:Deut.6.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.105.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.105.10",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.105.10",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Job.19.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Job.19.23",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "Pesachim 56a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 72,
        "ref": "Sirach 33:24",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 73,
        "ref": "WLC:Ps.39.7",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 77,
        "ref": "SBLGNT:Jas.5.12",
        "raw_ref": "SBLGNT:James.5.12",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 100,
        "ref": "WLC:Exod.17.12",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 100,
        "ref": "WLC:Exod.17.12",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 101,
        "ref": "WLC:Deut.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 101,
        "ref": "WLC:Deut.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 102,
        "ref": "WLC:Ps.89.34",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 102,
        "ref": "WLC:Ps.89.34",
        "field": "note",
        "language": "Hebrew",
        "wording": "אֱמוּנָה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 102,
        "ref": "WLC:Ps.89.34",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 103,
        "ref": "WLC:Deut.4.40",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 103,
        "ref": "WLC:Deut.4.40",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 104,
        "ref": "WLC:Exod.12.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 104,
        "ref": "WLC:Exod.12.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֻקָּה",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 104,
        "ref": "WLC:Exod.12.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 110,
        "ref": "SBLGNT:Jas.5.10",
        "raw_ref": "SBLGNT:James.5.10",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 111,
        "ref": "SBLGNT:Jas.5.11",
        "raw_ref": "SBLGNT:James.5.11",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 115,
        "ref": "Augustine, Confessions 9.11.27",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 126,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 126,
        "ref": "WLC:Isa.28.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 127,
        "ref": "WLC:2Chr.20.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Prov.31.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 129,
        "ref": "WLC:Prov.31.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 130,
        "ref": "Mishnah Avot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 131,
        "ref": "Tobit 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 140,
        "ref": "Didache 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 150,
        "ref": "Sirach 29:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 151,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 152,
        "ref": "Sirach 33:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 153,
        "ref": "WLC:Gen.41.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 156,
        "ref": "WLC:Ps.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 157,
        "ref": "WLC:Ps.78.37",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 157,
        "ref": "WLC:Ps.78.37",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 158,
        "ref": "WLC:Neh.9.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 158,
        "ref": "WLC:Neh.9.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec10/sol/followup.tsv",
    "rows": 54,
    "unique_references": 54,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 25,
      "medium": 29
    },
    "findings": [
      {
        "line": 11,
        "ref": "WLC:Isa.28.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 11,
        "ref": "WLC:Isa.28.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:2Chr.20.20",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:2Chr.20.20",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Prov.31.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 14,
        "ref": "WLC:Prov.31.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 15,
        "ref": "Mishnah Avot 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 16,
        "ref": "Tobit 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 25,
        "ref": "Didache 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 35,
        "ref": "Sirach 29:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "Sirach 33:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "WLC:Gen.41.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.2.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.78.37",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.78.37",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Neh.9.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Neh.9.8",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמנ",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 365472,
    "cached_input_tokens": 308096,
    "cache_write_input_tokens": 0,
    "output_tokens": 29551,
    "reasoning_output_tokens": 17081,
    "total_tokens": 395023
  }
}
```

## sec11 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec11/luna/list.tsv",
    "rows": 82,
    "unique_references": 80,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 44,
      "medium": 38
    },
    "findings": [
      {
        "line": 12,
        "ref": "Wisdom of Solomon 18:15-16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 13,
        "ref": "Sirach 21:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 27,
        "ref": "WLC:Neh.9.13",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 27,
        "ref": "WLC:Neh.9.13",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 28,
        "ref": "WLC:Eccl.1.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "WLC:Eccl.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "Mishnah Rosh Hashanah 3:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "4 Ezra 13:10-11",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "Sirach 28:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 58,
        "ref": "Sirach 28:18",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 59,
        "ref": "Wisdom of Solomon 5:17-20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 62,
        "ref": "WLC:Eccl.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 66,
        "ref": "WLC:Prov.14.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 70,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 71,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 78,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 79,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec11/luna/followup.tsv",
    "rows": 34,
    "unique_references": 33,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 19,
      "medium": 15
    },
    "findings": [
      {
        "line": 9,
        "ref": "Sirach 28:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 10,
        "ref": "Sirach 28:18",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 11,
        "ref": "Wisdom of Solomon 5:17-20",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "WLC:Eccl.4.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "WLC:Prov.14.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 22,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 23,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 30,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 31,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 214108,
    "cached_input_tokens": 107264,
    "cache_write_input_tokens": 0,
    "output_tokens": 56755,
    "reasoning_output_tokens": 50241,
    "total_tokens": 270863
  }
}
```

## sec11 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec11/sol/list.tsv",
    "rows": 129,
    "unique_references": 129,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 98,
      "medium": 31
    },
    "findings": [
      {
        "line": 14,
        "ref": "Wisdom of Solomon 18:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 15,
        "ref": "Wisdom of Solomon 18:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 16,
        "ref": "Wisdom of Solomon 5:21",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 29,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 30,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 35,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 37,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 38,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "WLC:Ps.119.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Ps.119.33",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 53,
        "ref": "WLC:Prov.8.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 54,
        "ref": "WLC:Job.38.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "Genesis Rabbah 8:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 69,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 71,
        "ref": "WLC:Neh.9.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 72,
        "ref": "WLC:Prov.10.21",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 73,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "Sirach 19:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 86,
        "ref": "Sirach 28:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 87,
        "ref": "Sirach 28:18",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 117,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 118,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 119,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 120,
        "ref": "WLC:Eccl.4.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 122,
        "ref": "WLC:Deut.28.48",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec11/sol/followup.tsv",
    "rows": 56,
    "unique_references": 56,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 46,
      "medium": 10
    },
    "findings": [
      {
        "line": 12,
        "ref": "Sirach 19:12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 13,
        "ref": "Sirach 28:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "Sirach 28:18",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 44,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 45,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Eccl.4.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 49,
        "ref": "WLC:Deut.28.48",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 177194,
    "cached_input_tokens": 148992,
    "cache_write_input_tokens": 0,
    "output_tokens": 20066,
    "reasoning_output_tokens": 11199,
    "total_tokens": 197260
  }
}
```

## sec12 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec12/luna/list.tsv",
    "rows": 68,
    "unique_references": 67,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 31,
      "medium": 36,
      "weak": 1
    },
    "findings": [
      {
        "line": 39,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עָמָל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "WLC:Job.19.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חָקַק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צָלַח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עָמָל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Deut.28.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צָלַח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Deut.28.29",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 55,
        "ref": "Shepherd of Hermas, Vision 3.2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 60,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 66,
        "ref": "WLC:Isa.49.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 67,
        "ref": "Babylonian Talmud, Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec12/luna/followup.tsv",
    "rows": 25,
    "unique_references": 25,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 11,
      "medium": 14
    },
    "findings": [
      {
        "line": 12,
        "ref": "Shepherd of Hermas, Vision 3.2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 17,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 23,
        "ref": "WLC:Isa.49.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 24,
        "ref": "Babylonian Talmud, Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 169473,
    "cached_input_tokens": 120576,
    "cache_write_input_tokens": 0,
    "output_tokens": 39207,
    "reasoning_output_tokens": 34308,
    "total_tokens": 208680
  }
}
```

## sec12 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec12/sol/list.tsv",
    "rows": 139,
    "unique_references": 138,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 60,
      "medium": 73,
      "weak": 6
    },
    "findings": [
      {
        "line": 6,
        "ref": "WLC:Ps.127.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 6,
        "ref": "WLC:Ps.127.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 7,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 7,
        "ref": "WLC:Eccl.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 8,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Ezra.5.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Ezra.6.14",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Ezra.6.14",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 11,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:Job.38.10",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:Job.38.10",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Lev.26.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Lev.26.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקות",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "SBLGNT:Jas.2.22",
        "raw_ref": "SBLGNT:James.2.22",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 38,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 57,
        "ref": "WLC:Isa.30.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 58,
        "ref": "WLC:Job.19.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 59,
        "ref": "WLC:Prov.8.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 68,
        "ref": "Pirkei Avot 3:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 76,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 83,
        "ref": "SBLGNT:Jas.5.19",
        "raw_ref": "SBLGNT:James.5.19",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 84,
        "ref": "Shepherd of Hermas, Vision 3.2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 104,
        "ref": "WLC:Isa.53.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 105,
        "ref": "WLC:Jer.31.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 128,
        "ref": "Pirkei Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 136,
        "ref": "Shepherd of Hermas, Vision 3.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 137,
        "ref": "1 Clement 37:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 138,
        "ref": "1 Clement 38:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 139,
        "ref": "Ignatius, Ephesians 9:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec12/sol/followup.tsv",
    "rows": 44,
    "unique_references": 44,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 16,
      "medium": 28
    },
    "findings": [
      {
        "line": 9,
        "ref": "WLC:Isa.53.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Jer.31.36",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 33,
        "ref": "Pirkei Avot 1:17",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "Shepherd of Hermas, Vision 3.3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 42,
        "ref": "1 Clement 37:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 43,
        "ref": "1 Clement 38:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 44,
        "ref": "Ignatius, Ephesians 9:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 252584,
    "cached_input_tokens": 208384,
    "cache_write_input_tokens": 0,
    "output_tokens": 22503,
    "reasoning_output_tokens": 12314,
    "total_tokens": 275087
  }
}
```

## sec13 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec13/luna/list.tsv",
    "rows": 104,
    "unique_references": 102,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 79,
      "medium": 25
    },
    "findings": [
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "ח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "ס",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 1,
        "ref": "WLC:Dan.5.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "ר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 16,
        "ref": "WLC:Eccl.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 17,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 18,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 19,
        "ref": "Mishnah Avot 3:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 20,
        "ref": "Kiddushin 40b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 21,
        "ref": "1 Enoch 41:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 22,
        "ref": "Testament of Abraham, Recension A 13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 23,
        "ref": "Wisdom of Solomon 3:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 46,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 47,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חֹק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "WLC:Job.14.5",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "Rosh Hashanah 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 52,
        "ref": "Wisdom of Solomon 3:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 55,
        "ref": "Didache 16.2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 57,
        "ref": "Shavuot 39a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 69,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 70,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 71,
        "ref": "4 Ezra (2 Esdras) 7:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Justin Martyr, First Apology 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 95,
        "ref": "Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 96,
        "ref": "4 Ezra (2 Esdras) 7:33",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 97,
        "ref": "Wisdom of Solomon 5:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 102,
        "ref": "SBLGNT:Jas.1.15",
        "raw_ref": "SBLGNT:James.1.15",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 104,
        "ref": "Shepherd of Hermas, Mandate 5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec13/luna/followup.tsv",
    "rows": 47,
    "unique_references": 47,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 33,
      "medium": 14
    },
    "findings": [
      {
        "line": 12,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 13,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "4 Ezra (2 Esdras) 7:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 33,
        "ref": "Justin Martyr, First Apology 12",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "Arakhin 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 39,
        "ref": "4 Ezra (2 Esdras) 7:33",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 40,
        "ref": "Wisdom of Solomon 5:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 45,
        "ref": "SBLGNT:Jas.1.15",
        "raw_ref": "SBLGNT:James.1.15",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 47,
        "ref": "Shepherd of Hermas, Mandate 5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 356369,
    "cached_input_tokens": 282624,
    "cache_write_input_tokens": 0,
    "output_tokens": 54075,
    "reasoning_output_tokens": 43436,
    "total_tokens": 410444
  }
}
```

## sec13 / sol / s103-20261009

```json
{
  "diagnostics": [
    {
      "call_id": "call_e847d610ee9a404cb0e00c80130de625",
      "message": "Script failed"
    },
    {
      "call_id": "call_e847d610ee9a404cb0e00c80130de625",
      "message": "Script error:"
    },
    {
      "call_id": "call_e847d610ee9a404cb0e00c80130de625",
      "message": "apply_patch verification failed: Failed to find expected lines in /Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec13/sol/list.tsv:"
    }
  ],
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec13/sol/list.tsv",
    "rows": 148,
    "unique_references": 146,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 102,
      "medium": 40,
      "weak": 6
    },
    "findings": [
      {
        "line": 2,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 9,
        "ref": "WLC:Eccl.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 10,
        "ref": "WLC:Eccl.2.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "WLC:Job.14.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 29,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "WLC:Josh.1.8",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 31,
        "ref": "WLC:Jer.12.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 32,
        "ref": "WLC:Ps.37.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 33,
        "ref": "WLC:Dan.6.29",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 34,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "WLC:Ps.34.11",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 76,
        "ref": "SBLGNT:Jas.5.3",
        "raw_ref": "SBLGNT:James.5.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 84,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "WLC:Job.5.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עמל",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 89,
        "ref": "Mishnah Rosh Hashanah 1:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Babylonian Talmud Rosh Hashanah 16b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "Babylonian Talmud Kiddushin 40b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 92,
        "ref": "Mishnah Avot 3:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 93,
        "ref": "Mishnah Avot 4:11",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 94,
        "ref": "Mishnah Avot 4:22",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 95,
        "ref": "Mishnah Avot 2:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 99,
        "ref": "SBLGNT:Jas.5.9",
        "raw_ref": "SBLGNT:James.5.9",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 106,
        "ref": "WLC:Job.27.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 108,
        "ref": "WLC:Ps.39.7",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צבר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 117,
        "ref": "2 Baruch 24:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 118,
        "ref": "4 Ezra 7:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 119,
        "ref": "Sirach 11:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 122,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 133,
        "ref": "WLC:Prov.14.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 134,
        "ref": "WLC:Zeph.2.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 136,
        "ref": "1 Enoch 47:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 145,
        "ref": "Augustine, City of God 20.14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 146,
        "ref": "WLC:1Sam.2.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "לו",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 147,
        "ref": "WLC:1Sam.2.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "לו",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 148,
        "ref": "Testament of Abraham, Recension A 13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec13/sol/followup.tsv",
    "rows": 40,
    "unique_references": 39,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 23,
      "medium": 14,
      "weak": 3
    },
    "findings": [
      {
        "line": 9,
        "ref": "2 Baruch 24:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 10,
        "ref": "4 Ezra 7:35",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 11,
        "ref": "Sirach 11:26",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "SBLGNT:Jas.2.17",
        "raw_ref": "SBLGNT:James.2.17",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 25,
        "ref": "WLC:Prov.14.23",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 26,
        "ref": "WLC:Zeph.2.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 28,
        "ref": "1 Enoch 47:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "Augustine, City of God 20.14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 38,
        "ref": "WLC:1Sam.2.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "לו",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 39,
        "ref": "WLC:1Sam.2.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "לו",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 40,
        "ref": "Testament of Abraham, Recension A 13",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 322669,
    "cached_input_tokens": 289408,
    "cache_write_input_tokens": 0,
    "output_tokens": 23643,
    "reasoning_output_tokens": 12705,
    "total_tokens": 346312
  }
}
```

## sec14 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec14/luna/list.tsv",
    "rows": 91,
    "unique_references": 90,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 61,
      "medium": 30
    },
    "findings": [
      {
        "line": 8,
        "ref": "Mishnah Sanhedrin 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 9,
        "ref": "Wisdom of Solomon 6:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 10,
        "ref": "Wisdom of Solomon 5:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 11,
        "ref": "Sirach 10:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 20,
        "ref": "SBLGNT:Jas.2.2",
        "raw_ref": "SBLGNT:James.2.2",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 21,
        "ref": "SBLGNT:Jas.2.3",
        "raw_ref": "SBLGNT:James.2.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 22,
        "ref": "SBLGNT:Jas.2.5",
        "raw_ref": "SBLGNT:James.2.5",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 23,
        "ref": "SBLGNT:Jas.2.9",
        "raw_ref": "SBLGNT:James.2.9",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 41,
        "ref": "WLC:Job.14.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Job.14.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.103.16",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Ps.103.16",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנוש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "WLC:Prov.13.25",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 44,
        "ref": "WLC:Ps.23.2",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 46,
        "ref": "Pirkei Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 83,
        "ref": "WLC:Exod.16.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Exod.16.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 88,
        "ref": "Sanhedrin 37a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 89,
        "ref": "1 Clement 13:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 90,
        "ref": "Didache 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec14/luna/followup.tsv",
    "rows": 38,
    "unique_references": 37,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 27,
      "medium": 11
    },
    "findings": [
      {
        "line": 30,
        "ref": "WLC:Exod.16.18",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 30,
        "ref": "WLC:Exod.16.18",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 35,
        "ref": "Sanhedrin 37a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "1 Clement 13:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 37,
        "ref": "Didache 4:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 476883,
    "cached_input_tokens": 390912,
    "cache_write_input_tokens": 0,
    "output_tokens": 70368,
    "reasoning_output_tokens": 62769,
    "total_tokens": 547251
  }
}
```

## sec14 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec14/sol/list.tsv",
    "rows": 120,
    "unique_references": 120,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 82,
      "medium": 36,
      "weak": 2
    },
    "findings": [
      {
        "line": 14,
        "ref": "Mishnah Sanhedrin 4:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 36,
        "ref": "WLC:Dan.5.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 47,
        "ref": "Wisdom of Solomon 5:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 48,
        "ref": "Wisdom of Solomon 5:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 49,
        "ref": "WLC:Ps.8.5",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 50,
        "ref": "WLC:Ps.103.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 51,
        "ref": "WLC:Ps.90.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Prov.28.27",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 61,
        "ref": "WLC:Prov.28.27",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "Mishnah Avot 4:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 63,
        "ref": "Mishnah Avot 3:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 64,
        "ref": "Wisdom of Solomon 6:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 71,
        "ref": "WLC:Ps.23.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 71,
        "ref": "WLC:Ps.23.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 83,
        "ref": "WLC:Prov.13.25",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 84,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 85,
        "ref": "Mishnah Horayot 3:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 86,
        "ref": "Sirach 10:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 87,
        "ref": "Wisdom of Solomon 6:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 113,
        "ref": "WLC:Jer.17.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 113,
        "ref": "WLC:Jer.17.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 114,
        "ref": "WLC:Job.25.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 115,
        "ref": "Sanhedrin 108b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec14/sol/followup.tsv",
    "rows": 48,
    "unique_references": 48,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 34,
      "medium": 14
    },
    "findings": [
      {
        "line": 11,
        "ref": "WLC:Prov.13.25",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 11,
        "ref": "WLC:Prov.13.25",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 12,
        "ref": "WLC:Job.4.17",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 13,
        "ref": "Mishnah Horayot 3:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "Sirach 10:19",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 15,
        "ref": "Wisdom of Solomon 6:6",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 41,
        "ref": "WLC:Jer.17.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 41,
        "ref": "WLC:Jer.17.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 42,
        "ref": "WLC:Job.25.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אנש",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 43,
        "ref": "Sanhedrin 108b",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 141038,
    "cached_input_tokens": 105472,
    "cache_write_input_tokens": 0,
    "output_tokens": 18668,
    "reasoning_output_tokens": 11381,
    "total_tokens": 159706
  }
}
```

## sec15 / luna / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec15/luna/list.tsv",
    "rows": 131,
    "unique_references": 131,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 98,
      "medium": 33
    },
    "findings": [
      {
        "line": 12,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 13,
        "ref": "Mishnah Avot 2:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 14,
        "ref": "Mishnah Peah 1:1",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Sirach 29:3",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 31,
        "ref": "Shabbat 31a",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 46,
        "ref": "Sirach 2:4",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 47,
        "ref": "Sirach 2:5",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 91,
        "ref": "Mishnah Avot 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 110,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 122,
        "ref": "Mishnah Avot 4:11",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec15/luna/followup.tsv",
    "rows": 39,
    "unique_references": 39,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 36,
      "medium": 3
    },
    "findings": [
      {
        "line": 18,
        "ref": "Sirach 29:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 30,
        "ref": "Mishnah Avot 4:11",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 320647,
    "cached_input_tokens": 240128,
    "cache_write_input_tokens": 0,
    "output_tokens": 71980,
    "reasoning_output_tokens": 60657,
    "total_tokens": 392627
  }
}
```

## sec15 / sol / s103-20261009

```json
{
  "validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec15/sol/list.tsv",
    "rows": 204,
    "unique_references": 201,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 126,
      "medium": 76,
      "weak": 2
    },
    "findings": [
      {
        "line": 47,
        "ref": "SBLGNT:Jas.5.7",
        "raw_ref": "SBLGNT:James.5.7",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 69,
        "ref": "SBLGNT:Jas.4.14",
        "raw_ref": "SBLGNT:James.4.14",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 73,
        "ref": "SBLGNT:Jas.2.16",
        "raw_ref": "SBLGNT:James.2.16",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 91,
        "ref": "SBLGNT:Jas.5.20",
        "raw_ref": "SBLGNT:James.5.20",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 105,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 106,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 107,
        "ref": "1 Clement 12:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 108,
        "ref": "1 Clement 38:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 109,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 138,
        "ref": "SBLGNT:Jas.2.25",
        "raw_ref": "SBLGNT:James.2.25",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 154,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 163,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 164,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 165,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 166,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 166,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 167,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 194,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 194,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 195,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 195,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחסור",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 195,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 198,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 198,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 199,
        "ref": "WLC:Judg.13.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 199,
        "ref": "WLC:Judg.13.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 200,
        "ref": "Tobit 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 201,
        "ref": "Sirach 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 202,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 203,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 203,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 204,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 204,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "raw_proposal_validation": {
    "file": "/Volumes/aro/projects/prose_generation/enrichment/bible/work/s103/discovery/s103-20261009/sec15/sol/followup.tsv",
    "rows": 100,
    "unique_references": 98,
    "schema_errors": [],
    "duplicates": [],
    "strengths": {
      "strong": 63,
      "medium": 35,
      "weak": 2
    },
    "findings": [
      {
        "line": 1,
        "ref": "Mishnah Avot 2:15",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 2,
        "ref": "Mishnah Avot 1:14",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 3,
        "ref": "1 Clement 12:7",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 4,
        "ref": "1 Clement 38:2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 5,
        "ref": "Shepherd of Hermas, Similitude 2",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 34,
        "ref": "SBLGNT:Jas.2.25",
        "raw_ref": "SBLGNT:James.2.25",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 50,
        "ref": "SBLGNT:Jas.5.4",
        "raw_ref": "SBLGNT:James.5.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 59,
        "ref": "SBLGNT:Jas.1.3",
        "raw_ref": "SBLGNT:James.1.3",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 60,
        "ref": "SBLGNT:Jas.1.4",
        "raw_ref": "SBLGNT:James.1.4",
        "kind": "reference_alias",
        "resolver": "edition-book-names-v2",
        "message": "Unambiguous book name resolved to its corpus code; raw row, edition and verse numbering unchanged."
      },
      {
        "line": 61,
        "ref": "WLC:Gen.15.6",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Isa.7.9",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 62,
        "ref": "WLC:Isa.7.9",
        "field": "note",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 63,
        "ref": "WLC:Hab.2.4",
        "field": "basis",
        "language": "Hebrew",
        "wording": "אמן",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:Ps.1.3",
        "field": "basis",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 90,
        "ref": "WLC:Ps.1.3",
        "field": "note",
        "language": "Hebrew",
        "wording": "צלח",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Prov.11.24",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "מחסור",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 91,
        "ref": "WLC:Prov.11.24",
        "field": "note",
        "language": "Hebrew",
        "wording": "חסר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 94,
        "ref": "WLC:1Kgs.8.35",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 94,
        "ref": "WLC:1Kgs.8.35",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 95,
        "ref": "WLC:Judg.13.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 95,
        "ref": "WLC:Judg.13.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "עצר",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 96,
        "ref": "Tobit 4:16",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 97,
        "ref": "Sirach 4:9",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 98,
        "ref": "Didache 4:8",
        "kind": "unresolved_text",
        "message": "Named work requires prefetch or an explicit unavailable verdict."
      },
      {
        "line": 99,
        "ref": "WLC:Prov.8.15",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 99,
        "ref": "WLC:Prov.8.15",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 100,
        "ref": "WLC:Isa.10.1",
        "field": "basis",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      },
      {
        "line": 100,
        "ref": "WLC:Isa.10.1",
        "field": "note",
        "language": "Hebrew",
        "wording": "חקק",
        "kind": "wording_review",
        "variant_matches": [],
        "matching_neighbours": [],
        "message": "Wording absent from cited main text; review quotation, root/form, witness and verse boundary."
      }
    ],
    "reference_resolver": "edition-book-names-v2",
    "limits": "Wording and reference checks only; no semantic, relevance, historical or cognacy validation. Pointing/accents are normalized; roots, inflections, orthography, segmentation and named witnesses require review. Qere is separate from the WLC ketiv text. Unmatched spans are findings, not automatic rejection; a match does not verify a connection."
  },
  "usage_tokens": {
    "input_tokens": 235243,
    "cached_input_tokens": 177920,
    "cache_write_input_tokens": 0,
    "output_tokens": 29931,
    "reasoning_output_tokens": 15360,
    "total_tokens": 265174
  }
}
```

## Dry handoff

```json
[
  {
    "target": "103:1",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 269,
    "overlap": 42,
    "connections": 313,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "103:2",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 225,
    "overlap": 48,
    "connections": 279,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "103:3",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 388,
    "overlap": 92,
    "connections": 498,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec1",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 275,
    "overlap": 76,
    "connections": 356,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec2",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 258,
    "overlap": 53,
    "connections": 311,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec3",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 167,
    "overlap": 41,
    "connections": 210,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec4",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 243,
    "overlap": 34,
    "connections": 280,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec5",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 307,
    "overlap": 57,
    "connections": 364,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec6",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 218,
    "overlap": 53,
    "connections": 274,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec7",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 275,
    "overlap": 73,
    "connections": 351,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec8",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 268,
    "overlap": 62,
    "connections": 348,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec9",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 270,
    "overlap": 77,
    "connections": 351,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec10",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 218,
    "overlap": 45,
    "connections": 264,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec11",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 171,
    "overlap": 38,
    "connections": 211,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec12",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 157,
    "overlap": 48,
    "connections": 207,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec13",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 183,
    "overlap": 65,
    "connections": 252,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec14",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 160,
    "overlap": 50,
    "connections": 211,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  },
  {
    "target": "sec15",
    "run_tag": "s103-20261009",
    "dry_handoff": true,
    "unique_references": 280,
    "overlap": 52,
    "connections": 335,
    "page_author_estimate": "No Bible live-call calibration yet; use enrich.py build after prefetch/indexing."
  }
]
```

Ready to merge: True. Recorded charge: $0.00; API-equivalent $8.91 (codex exec readers). No model calls.

Reader labels and wording findings are unverified. Prefetch, index build and complete verdicts remain required.
